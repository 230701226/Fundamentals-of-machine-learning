import { pgTable, text, serial, jsonb } from "drizzle-orm/pg-core";

export const questionsTable = pgTable("questions", {
  id: serial("id").primaryKey(),
  companyId: text("company_id").notNull(),
  roleId: text("role_id").notNull(),
  text: text("text").notNull(),
  topic: text("topic").notNull(),
  difficulty: text("difficulty").notNull(),
  type: text("type").notNull().default("behavioral"),
  hints: jsonb("hints").$type<string[]>().notNull().default([]),
  followUpPrompt: text("follow_up_prompt"),
  keywords: jsonb("keywords").$type<string[]>().notNull().default([]),
});

export type Question = typeof questionsTable.$inferSelect;
