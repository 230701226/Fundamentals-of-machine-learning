import { pgTable, text, integer } from "drizzle-orm/pg-core";

export const companiesTable = pgTable("companies", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  logo: text("logo"),
  industry: text("industry").notNull(),
  questionCount: integer("question_count").notNull().default(0),
});

export type Company = typeof companiesTable.$inferSelect;
