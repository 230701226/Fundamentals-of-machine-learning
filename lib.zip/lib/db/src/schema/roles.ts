import { pgTable, text } from "drizzle-orm/pg-core";

export const rolesTable = pgTable("roles", {
  id: text("id").primaryKey(),
  companyId: text("company_id").notNull(),
  title: text("title").notNull(),
  category: text("category").notNull(),
  description: text("description").notNull(),
});

export type Role = typeof rolesTable.$inferSelect;
