import { pgTable, text, serial, integer, numeric, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const sessionsTable = pgTable("sessions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  companyId: text("company_id").notNull(),
  roleId: text("role_id").notNull(),
  interviewType: text("interview_type").notNull().default("text"),
  mode: text("mode").notNull().default("normal"),
  status: text("status").notNull().default("active"),
  skillLevel: text("skill_level").notNull().default("beginner"),
  totalQuestions: integer("total_questions").notNull().default(10),
  answeredQuestions: integer("answered_questions").notNull().default(0),
  currentDifficulty: text("current_difficulty").notNull().default("beginner"),
  overallScore: numeric("overall_score", { precision: 5, scale: 2 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  completedAt: timestamp("completed_at", { withTimezone: true }),
});

export const insertSessionSchema = createInsertSchema(sessionsTable).omit({ id: true, createdAt: true });
export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessionsTable.$inferSelect;
