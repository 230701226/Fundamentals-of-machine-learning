import { Switch, Route, Router as WouterRouter, Redirect, useLocation } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { Layout } from "@/components/Layout";
import { Loader2 } from "lucide-react";
import Home from "@/pages/Home";
import Setup from "@/pages/Setup";
import Interview from "@/pages/Interview";
import Results from "@/pages/Results";
import Dashboard from "@/pages/Dashboard";
import Progress from "@/pages/Progress";
import WeakAreas from "@/pages/WeakAreas";
import Recommendations from "@/pages/Recommendations";
import Replay from "@/pages/Replay";
import Resume from "@/pages/Resume";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      staleTime: 30_000,
    },
  },
});

function AuthGuard({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth();
  const [location] = useLocation();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  const publicPaths = ["/login", "/register"];
  if (!user && !publicPaths.includes(location)) {
    return <Redirect to="/login" />;
  }

  return <>{children}</>;
}

function Router() {
  return (
    <AuthGuard>
      <Layout>
        <Switch>
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          <Route path="/" component={Home} />
          <Route path="/setup" component={Setup} />
          <Route path="/interview/:sessionId" component={Interview} />
          <Route path="/results/:sessionId" component={Results} />
          <Route path="/replay/:sessionId" component={Replay} />
          <Route path="/resume" component={Resume} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/progress" component={Progress} />
          <Route path="/weak-areas" component={WeakAreas} />
          <Route path="/recommendations" component={Recommendations} />
          <Route component={NotFound} />
        </Switch>
      </Layout>
    </AuthGuard>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <Router />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
