import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import {
  BrainCircuit, Play, BarChart2, Mic, Target, ChevronRight, X, Zap, TrendingUp
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { useAuth } from "@/contexts/AuthContext";

const STORAGE_KEY = "interview-twin-onboarding-done";

const steps = [
  {
    icon: BrainCircuit,
    iconColor: "text-primary",
    iconBg: "bg-primary/15",
    title: "Welcome to AI Interview Twin",
    subtitle: "Your personalized mock interview coach that gets smarter as you practice",
    content: (
      <div className="grid grid-cols-2 gap-3 mt-4">
        {[
          { icon: Zap, label: "NLP Scoring", desc: "AI evaluates your answers in real-time" },
          { icon: Target, label: "Weak Areas", desc: "Identifies exactly where you need to improve" },
          { icon: TrendingUp, label: "Adaptive", desc: "Questions adjust to your performance level" },
          { icon: BarChart2, label: "Analytics", desc: "Detailed dashboard tracks your growth" },
        ].map(item => (
          <div key={item.label} className="bg-background rounded-lg p-3 border border-border">
            <item.icon className="h-4 w-4 text-primary mb-1.5" />
            <div className="text-xs font-semibold mb-0.5">{item.label}</div>
            <div className="text-xs text-muted-foreground">{item.desc}</div>
          </div>
        ))}
      </div>
    ),
  },
  {
    icon: Play,
    iconColor: "text-green-400",
    iconBg: "bg-green-500/15",
    title: "How an interview works",
    subtitle: "Simple 4-step cycle that simulates a real interview experience",
    content: (
      <ol className="mt-4 space-y-3">
        {[
          { step: "1", text: "Choose a company (Amazon, Google, etc.) and your target role" },
          { step: "2", text: "Answer questions by typing or speaking — STAR method recommended" },
          { step: "3", text: "Get instant AI feedback on quality, structure, and confidence" },
          { step: "4", text: "Questions automatically adapt in difficulty based on your scores" },
        ].map(item => (
          <li key={item.step} className="flex items-start gap-3">
            <span className="h-6 w-6 rounded-full bg-primary/20 text-primary text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
              {item.step}
            </span>
            <span className="text-sm text-muted-foreground leading-snug">{item.text}</span>
          </li>
        ))}
      </ol>
    ),
  },
  {
    icon: Mic,
    iconColor: "text-blue-400",
    iconBg: "bg-blue-500/15",
    title: "The STAR Method",
    subtitle: "The single most effective interview technique — use it for every answer",
    content: (
      <div className="mt-4 space-y-2">
        {[
          { letter: "S", label: "Situation", desc: "Set the scene. What was the context or challenge?", color: "text-blue-400 bg-blue-500/10 border-blue-500/20" },
          { letter: "T", label: "Task", desc: "What was your specific role and responsibility?", color: "text-yellow-400 bg-yellow-500/10 border-yellow-500/20" },
          { letter: "A", label: "Action", desc: "What specific steps did YOU take? Be detailed.", color: "text-primary bg-primary/10 border-primary/20" },
          { letter: "R", label: "Result", desc: "What was the measurable outcome? Quantify when possible.", color: "text-green-400 bg-green-500/10 border-green-500/20" },
        ].map(item => (
          <div key={item.letter} className={`flex items-start gap-3 p-2.5 rounded-lg border ${item.color}`}>
            <span className={`text-lg font-black shrink-0 ${item.color.split(" ")[0]}`}>{item.letter}</span>
            <div>
              <div className="text-sm font-semibold">{item.label}</div>
              <div className="text-xs text-muted-foreground">{item.desc}</div>
            </div>
          </div>
        ))}
      </div>
    ),
  },
  {
    icon: Target,
    iconColor: "text-primary",
    iconBg: "bg-primary/15",
    title: "You're ready to start",
    subtitle: "Pick a company, choose your role, and jump into your first interview",
    content: (
      <div className="mt-4 space-y-3">
        <div className="p-3 bg-primary/10 border border-primary/20 rounded-lg">
          <p className="text-sm text-primary font-medium mb-1">Quick tip for your first session</p>
          <p className="text-xs text-muted-foreground">
            Start with a Behavioral interview at Beginner difficulty. Focus on using the STAR structure —
            the system will increase difficulty automatically as you improve.
          </p>
        </div>
        <div className="text-xs text-muted-foreground text-center">
          Your progress is saved automatically and tracked in the Dashboard.
        </div>
      </div>
    ),
  },
];

export function Onboarding() {
  const { user } = useAuth();
  const [open, setOpen] = useState(() => {
    if (!user) return false;
    return !localStorage.getItem(STORAGE_KEY);
  });
  const [step, setStep] = useState(0);

  const dismiss = () => {
    localStorage.setItem(STORAGE_KEY, "1");
    setOpen(false);
  };

  const current = steps[step];
  const isLast = step === steps.length - 1;

  if (!open) return null;

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) dismiss(); }}>
      <DialogContent className="sm:max-w-md bg-card border-card-border p-0 overflow-hidden gap-0">
        <div className="relative p-6 pb-4">
          <button
            onClick={dismiss}
            className="absolute top-4 right-4 text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>

          {/* Step indicators */}
          <div className="flex gap-1.5 mb-5">
            {steps.map((_, i) => (
              <div
                key={i}
                className={`h-1 rounded-full transition-all duration-300 ${
                  i === step ? "bg-primary flex-[2]" : i < step ? "bg-primary/40 flex-1" : "bg-muted flex-1"
                }`}
              />
            ))}
          </div>

          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 15 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -15 }}
              transition={{ duration: 0.25 }}
            >
              <div className={`w-12 h-12 rounded-xl ${current.iconBg} flex items-center justify-center mb-4`}>
                <current.icon className={`h-6 w-6 ${current.iconColor}`} />
              </div>
              <h2 className="text-lg font-bold mb-1">{current.title}</h2>
              <p className="text-sm text-muted-foreground">{current.subtitle}</p>
              {current.content}
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="border-t border-border px-6 py-4 flex items-center justify-between">
          <button
            onClick={dismiss}
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            Skip tour
          </button>
          <div className="flex gap-2">
            {step > 0 && (
              <Button variant="outline" size="sm" onClick={() => setStep(s => s - 1)}>
                Back
              </Button>
            )}
            {isLast ? (
              <Link href="/setup" onClick={dismiss}>
                <Button size="sm" className="gap-1.5">
                  <Play className="h-3.5 w-3.5" />
                  Start interview
                </Button>
              </Link>
            ) : (
              <Button size="sm" className="gap-1.5" onClick={() => setStep(s => s + 1)}>
                Next
                <ChevronRight className="h-3.5 w-3.5" />
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
