import { useState } from "react";
import { Link, useLocation } from "wouter";
import {
  Home,
  BarChart,
  LineChart,
  Target,
  Lightbulb,
  BrainCircuit,
  Menu,
  LogOut,
  User,
  ChevronDown,
  FileText,
} from "lucide-react";
import { Button } from "./ui/button";
import { Sheet, SheetContent, SheetTrigger } from "./ui/sheet";
import { ScrollArea } from "./ui/scroll-area";
import { Avatar, AvatarFallback } from "./ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { useAuth } from "@/contexts/AuthContext";
import { Onboarding } from "./Onboarding";

const navItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "/dashboard", label: "Dashboard", icon: BarChart },
  { href: "/progress", label: "Progress", icon: LineChart },
  { href: "/weak-areas", label: "Weak Areas", icon: Target },
  { href: "/recommendations", label: "Recommendations", icon: Lightbulb },
  { href: "/resume", label: "Resume Analyzer", icon: FileText },
];

function UserMenu({ compact = false }: { compact?: boolean }) {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();

  const initials = user
    ? (user.displayName ?? user.username).slice(0, 2).toUpperCase()
    : "?";

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button className={`flex items-center gap-2.5 rounded-lg hover:bg-accent transition-colors ${compact ? "p-1" : "w-full p-2.5 border border-border bg-background"}`}>
          <Avatar className="h-8 w-8 rounded-full shrink-0">
            <AvatarFallback className="bg-primary/20 text-primary font-semibold text-xs">{initials}</AvatarFallback>
          </Avatar>
          {!compact && (
            <>
              <div className="flex flex-col text-left min-w-0">
                <span className="text-sm font-medium truncate">{user?.displayName ?? user?.username ?? "Guest"}</span>
                <span className="text-xs text-muted-foreground truncate">{user?.email ?? "Not signed in"}</span>
              </div>
              <ChevronDown className="h-3.5 w-3.5 text-muted-foreground ml-auto shrink-0" />
            </>
          )}
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48">
        {user ? (
          <>
            <div className="px-2 py-1.5 text-xs text-muted-foreground">
              Signed in as <span className="font-medium text-foreground">@{user.username}</span>
            </div>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout} className="text-destructive focus:text-destructive gap-2">
              <LogOut className="h-3.5 w-3.5" />
              Sign out
            </DropdownMenuItem>
          </>
        ) : (
          <DropdownMenuItem asChild>
            <Link href="/login" className="gap-2 cursor-pointer">
              <User className="h-3.5 w-3.5" />
              Sign in
            </Link>
          </DropdownMenuItem>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const isInterview = location.startsWith("/interview/");
  const isAuth = location === "/login" || location === "/register";

  if (isAuth) return <div className="min-h-screen bg-background">{children}</div>;
  if (isInterview) return <div className="min-h-screen bg-background">{children}</div>;

  return (
    <div className="flex min-h-screen flex-col md:flex-row bg-background">
      <Onboarding />

      {/* Mobile Header */}
      <header className="sticky top-0 z-40 flex h-14 shrink-0 items-center gap-x-3 border-b bg-background/95 backdrop-blur px-4 md:hidden">
        <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="-ml-2 h-8 w-8">
              <Menu className="h-4 w-4" />
              <span className="sr-only">Toggle menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64 p-0">
            <div className="flex h-14 items-center gap-2 px-5 border-b">
              <BrainCircuit className="h-5 w-5 text-primary" />
              <span className="font-bold tracking-tight text-sm">Interview Twin</span>
            </div>
            <ScrollArea className="h-[calc(100vh-3.5rem)] pb-10">
              <div className="flex flex-col gap-1 p-3">
                {navItems.map((item) => {
                  const active = location === item.href;
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      onClick={() => setMobileOpen(false)}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                        active ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-accent"
                      }`}
                    >
                      <item.icon className="h-4 w-4 shrink-0" />
                      {item.label}
                    </Link>
                  );
                })}
              </div>
              <div className="px-3 py-3 border-t mt-2">
                <UserMenu />
              </div>
            </ScrollArea>
          </SheetContent>
        </Sheet>

        <Link href="/" className="flex items-center gap-2">
          <BrainCircuit className="h-5 w-5 text-primary" />
          <span className="font-bold text-sm tracking-tight">Interview Twin</span>
        </Link>
        <div className="ml-auto">
          <UserMenu compact />
        </div>
      </header>

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-60 flex-col border-r bg-card h-screen sticky top-0 shrink-0">
        <div className="flex h-14 shrink-0 items-center gap-2.5 px-5 border-b">
          <BrainCircuit className="h-5 w-5 text-primary" />
          <span className="font-bold tracking-tight text-sm">Interview Twin</span>
        </div>
        <ScrollArea className="flex-1 py-3">
          <nav className="flex flex-col gap-1 px-3">
            {navItems.map((item) => {
              const active = location === item.href;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    active ? "bg-primary/15 text-primary" : "text-muted-foreground hover:text-foreground hover:bg-accent"
                  }`}
                >
                  <item.icon className="h-4 w-4 shrink-0" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
        </ScrollArea>
        <div className="border-t p-3">
          <UserMenu />
        </div>
      </aside>

      <main className="flex-1 w-full max-w-full overflow-x-hidden">
        {children}
      </main>
    </div>
  );
}
