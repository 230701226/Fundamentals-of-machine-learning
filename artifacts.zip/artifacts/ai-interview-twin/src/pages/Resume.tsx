import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Link } from "wouter";
import { FileText, Loader2, ChevronRight, X, Sparkles, Target, BookOpen, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { useAnalyzeResume } from "@workspace/api-client-react";

const TOPIC_DESCRIPTIONS: Record<string, string> = {
  "behavioral": "Situation-based questions about past experiences",
  "system-design": "Architecture, scalability, distributed systems",
  "technical": "Code, debugging, domain-specific questions",
  "algorithms": "Data structures, complexity, problem-solving",
  "leadership": "Team management, influence, ownership stories",
  "communication": "Stakeholder management, clarity, documentation",
  "problem-solving": "Structured analysis, root cause, tradeoffs",
  "data-structures": "Arrays, trees, graphs, heaps, queues",
};

const SKILL_COLOR: Record<string, string> = {
  "Python": "bg-blue-500/15 text-blue-400 border-blue-500/30",
  "JavaScript": "bg-yellow-500/15 text-yellow-400 border-yellow-500/30",
  "TypeScript": "bg-blue-600/15 text-blue-300 border-blue-600/30",
  "Java": "bg-orange-500/15 text-orange-400 border-orange-500/30",
  "SQL": "bg-purple-500/15 text-purple-400 border-purple-500/30",
  "Machine Learning": "bg-pink-500/15 text-pink-400 border-pink-500/30",
  "System Design": "bg-cyan-500/15 text-cyan-400 border-cyan-500/30",
  "Data Structures": "bg-green-500/15 text-green-400 border-green-500/30",
  "Cloud": "bg-sky-500/15 text-sky-400 border-sky-500/30",
  "DevOps": "bg-teal-500/15 text-teal-400 border-teal-500/30",
  "React": "bg-cyan-600/15 text-cyan-300 border-cyan-600/30",
  "Leadership": "bg-amber-500/15 text-amber-400 border-amber-500/30",
  "Communication": "bg-violet-500/15 text-violet-400 border-violet-500/30",
  "Agile": "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
};

const DEFAULT_SKILL_COLOR = "bg-muted text-muted-foreground border-border";

export default function Resume() {
  const [resumeText, setResumeText] = useState("");
  const [result, setResult] = useState<{
    detectedSkills: string[];
    experienceLevel: string;
    suggestedTopics: string[];
    summary: string;
    questionTopics: string[];
  } | null>(null);

  const analyzeResume = useAnalyzeResume();

  const handleAnalyze = async () => {
    if (!resumeText.trim()) return;
    try {
      const data = await analyzeResume.mutateAsync({ data: { resumeText: resumeText.trim() } });
      setResult(data);
    } catch (err) {
      console.error("Resume analysis failed", err);
    }
  };

  const handleClear = () => {
    setResumeText("");
    setResult(null);
  };

  return (
    <div className="min-h-screen px-4 py-6 md:px-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <Link href="/setup">
              <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold">Resume Analyzer</h1>
              <p className="text-sm text-muted-foreground">Paste your resume to get personalized interview preparation</p>
            </div>
          </div>
        </motion.div>

        {/* Input area */}
        <AnimatePresence mode="wait">
          {!result ? (
            <motion.div key="input" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <Card className="bg-card border-border mb-4">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <FileText className="h-4 w-4 text-primary" />
                    Paste your resume
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea
                    placeholder={`Paste your resume text here. Include:
• Work experience with job titles and descriptions
• Technical skills and technologies  
• Education and certifications
• Years of experience

The analyzer will detect your skill areas and suggest the most relevant interview topics to focus on.`}
                    value={resumeText}
                    onChange={(e) => setResumeText(e.target.value)}
                    className="min-h-[300px] bg-background border-border text-sm resize-none font-mono leading-relaxed"
                  />
                  <div className="flex items-center justify-between mt-3">
                    <span className="text-xs text-muted-foreground">{resumeText.split(/\s+/).filter(Boolean).length} words</span>
                    <div className="flex gap-2">
                      {resumeText && (
                        <Button variant="ghost" size="sm" onClick={handleClear} className="text-xs">
                          <X className="h-3.5 w-3.5 mr-1" /> Clear
                        </Button>
                      )}
                      <Button
                        onClick={handleAnalyze}
                        disabled={!resumeText.trim() || analyzeResume.isPending}
                        className="gap-2"
                      >
                        {analyzeResume.isPending
                          ? <><Loader2 className="h-4 w-4 animate-spin" /> Analyzing...</>
                          : <><Sparkles className="h-4 w-4" /> Analyze Resume</>
                        }
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {analyzeResume.isError && (
                <Card className="border-destructive/30 bg-destructive/5 mb-4">
                  <CardContent className="py-3 px-4 text-sm text-destructive">
                    Analysis failed. Please try again.
                  </CardContent>
                </Card>
              )}

              {/* Tips */}
              <Card className="bg-muted/30 border-border">
                <CardContent className="py-4 px-4">
                  <p className="text-xs font-semibold text-muted-foreground mb-3 uppercase tracking-wide">Tips for best results</p>
                  <ul className="space-y-2">
                    {[
                      "Include your full work history with job titles and descriptions",
                      "Mention all programming languages, frameworks, and tools you know",
                      "Include years of experience for each role",
                      "Add any certifications, degrees, or bootcamps",
                    ].map((tip, i) => (
                      <li key={i} className="text-xs text-muted-foreground flex gap-2">
                        <span className="text-primary shrink-0">•</span>{tip}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          ) : (
            <motion.div key="results" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">

              {/* Summary */}
              <Card className="bg-primary/5 border-primary/20">
                <CardContent className="py-4 px-4">
                  <div className="flex items-start gap-3">
                    <Sparkles className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-sm">Analysis Complete</span>
                        <Badge variant="outline" className="text-xs border-primary/30 text-primary">{result.experienceLevel}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground leading-relaxed">{result.summary}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Detected skills */}
              <Card className="bg-card border-border">
                <CardHeader className="pb-2 pt-4">
                  <CardTitle className="text-sm">Detected Skills ({result.detectedSkills.length})</CardTitle>
                </CardHeader>
                <CardContent className="pb-4">
                  {result.detectedSkills.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {result.detectedSkills.map((skill) => (
                        <Badge
                          key={skill}
                          variant="outline"
                          className={`text-xs border ${SKILL_COLOR[skill] ?? DEFAULT_SKILL_COLOR}`}
                        >
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">No specific skills detected. Try including more detail about your technical background.</p>
                  )}
                </CardContent>
              </Card>

              {/* Suggested interview topics */}
              <Card className="bg-card border-border">
                <CardHeader className="pb-2 pt-4">
                  <CardTitle className="text-sm flex items-center gap-2"><Target className="h-4 w-4 text-primary" /> Focus Topics for Your Interview</CardTitle>
                </CardHeader>
                <CardContent className="pb-4">
                  <div className="space-y-2.5">
                    {result.suggestedTopics.map((topic, i) => (
                      <motion.div key={topic} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.08 }}>
                        <div className="flex items-start gap-3 p-3 rounded-lg bg-muted/40">
                          <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold text-primary shrink-0">
                            {i + 1}
                          </div>
                          <div>
                            <div className="text-sm font-medium capitalize">{topic}</div>
                            <div className="text-xs text-muted-foreground mt-0.5">{TOPIC_DESCRIPTIONS[topic] ?? "Practice questions for this area"}</div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Preparation guide */}
              <Card className="bg-card border-border">
                <CardHeader className="pb-2 pt-4">
                  <CardTitle className="text-sm flex items-center gap-2"><BookOpen className="h-4 w-4 text-primary" /> Preparation Plan</CardTitle>
                </CardHeader>
                <CardContent className="pb-4">
                  <ul className="space-y-2">
                    {[
                      `Practice 5+ questions per topic in your focus areas`,
                      `Use the STAR method for all behavioral answers`,
                      `Prepare 2-3 deep technical examples from your experience`,
                      `Research interview styles for your target company`,
                      `Time yourself — aim for 90-120 seconds per answer`,
                    ].map((step, i) => (
                      <li key={i} className="flex gap-2 text-xs text-muted-foreground">
                        <span className="text-primary shrink-0 font-semibold">{i + 1}.</span>
                        {step}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              {/* CTA */}
              <div className="flex gap-3">
                <Button variant="outline" onClick={handleClear} className="flex-1 gap-2">
                  <X className="h-4 w-4" /> Analyze Another
                </Button>
                <Link href="/setup" className="flex-1">
                  <Button className="w-full gap-2">
                    <ChevronRight className="h-4 w-4" /> Start Interview
                  </Button>
                </Link>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
