import { motion } from "framer-motion";
import { Link } from "wouter";
import { Play, Lightbulb, ArrowRight, Zap, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useGetRecommendations } from "@workspace/api-client-react";

const difficultyConfig = {
  beginner: "border-green-500/30 text-green-400 bg-green-500/5",
  intermediate: "border-yellow-500/30 text-yellow-400 bg-yellow-500/5",
  advanced: "border-primary/30 text-primary bg-primary/5",
};

const impactColor = (impact: string) => {
  if (impact.toLowerCase().startsWith("very high")) return "text-red-400";
  if (impact.toLowerCase().startsWith("high")) return "text-orange-400";
  return "text-yellow-400";
};

function RecommendationSkeleton() {
  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-3">
        <div className="flex items-start gap-3">
          <Skeleton className="h-8 w-8 rounded-lg shrink-0" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-4 w-32" />
            <div className="flex gap-2">
              <Skeleton className="h-5 w-20 rounded-full" />
              <Skeleton className="h-5 w-24 rounded-full" />
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-0 space-y-3">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-3/4" />
        <div className="p-3 rounded-lg bg-background border border-border space-y-2">
          <Skeleton className="h-3 w-24" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-5/6" />
        </div>
      </CardContent>
    </Card>
  );
}

export default function Recommendations() {
  const { data: recommendations, isLoading, error, refetch } = useGetRecommendations();

  return (
    <div className="min-h-screen px-4 py-6 md:px-8">
      <div className="max-w-3xl mx-auto">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
          <h1 className="text-2xl font-bold mb-1">Recommendations</h1>
          <p className="text-sm text-muted-foreground">
            Personalized next steps based on your performance history
          </p>
        </motion.div>

        {isLoading ? (
          <div className="space-y-4">
            {[0, 1, 2].map(i => <RecommendationSkeleton key={i} />)}
          </div>
        ) : error ? (
          <Card className="bg-card border-border border-dashed">
            <CardContent className="py-16 text-center">
              <p className="text-muted-foreground text-sm mb-4">Failed to load recommendations.</p>
              <Button variant="outline" onClick={() => refetch()}>Try again</Button>
            </CardContent>
          </Card>
        ) : !recommendations || recommendations.length === 0 ? (
          <Card className="bg-card border-border border-dashed">
            <CardContent className="py-16 text-center">
              <Lightbulb className="h-12 w-12 text-yellow-400 mx-auto mb-4 opacity-60" />
              <h3 className="font-semibold text-lg mb-2">No recommendations yet</h3>
              <p className="text-muted-foreground text-sm mb-6 max-w-sm mx-auto">
                Complete a few interview sessions so we can generate personalized recommendations for you.
              </p>
              <Link href="/setup">
                <Button className="gap-2"><Play className="h-4 w-4" /> Start Interview</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {recommendations.map((rec, i) => {
              const diffConfig = difficultyConfig[rec.difficulty as keyof typeof difficultyConfig] ?? difficultyConfig.intermediate;

              return (
                <motion.div key={rec.topic} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
                  <Card className="bg-card border-border">
                    <CardHeader className="pb-3">
                      <div className="flex items-start gap-3">
                        <div className="h-8 w-8 rounded-lg bg-primary/20 flex items-center justify-center shrink-0">
                          <span className="text-primary font-bold text-sm">{i + 1}</span>
                        </div>
                        <div className="flex-1">
                          <CardTitle className="text-base capitalize">{rec.topic}</CardTitle>
                          <div className="flex items-center gap-2 mt-1 flex-wrap">
                            <Badge variant="outline" className={`text-xs capitalize ${diffConfig}`}>{rec.difficulty}</Badge>
                            <span className={`text-xs font-medium flex items-center gap-0.5 ${impactColor(rec.estimatedImpact)}`}>
                              <Zap className="h-3 w-3" />{rec.estimatedImpact}
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="pt-0 space-y-3">
                      <div className="flex items-start gap-2">
                        <Lightbulb className="h-4 w-4 text-yellow-400 shrink-0 mt-0.5" />
                        <p className="text-sm text-muted-foreground leading-relaxed">{rec.reason}</p>
                      </div>

                      {/* Sample Question */}
                      <div className="p-3 rounded-lg bg-background border border-border">
                        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Sample Question</div>
                        <p className="text-sm font-medium leading-snug">{rec.sampleQuestion}</p>
                      </div>

                      {/* Actionable Steps */}
                      {rec.actionableSteps && rec.actionableSteps.length > 0 && (
                        <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
                          <div className="text-xs font-semibold text-primary uppercase tracking-wide mb-2">Action Plan</div>
                          <ul className="space-y-1.5">
                            {rec.actionableSteps.map((step, si) => (
                              <li key={si} className="flex gap-2 text-xs text-muted-foreground">
                                <ChevronRight className="h-3.5 w-3.5 text-primary shrink-0 mt-0.5" />
                                {step}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <div className="flex justify-end">
                        <Link href="/setup">
                          <Button size="sm" variant="outline" className="gap-1.5 text-xs">
                            Practice this topic <ArrowRight className="h-3.5 w-3.5" />
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
