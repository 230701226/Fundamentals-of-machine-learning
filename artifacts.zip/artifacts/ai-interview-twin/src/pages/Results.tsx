import { useParams, Link } from "wouter";
import { motion } from "framer-motion";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line, CartesianGrid
} from "recharts";
import { ArrowLeft, BarChart2, CheckCircle2, AlertCircle, Loader2, Play, Home } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useGetSessionAnalytics, useGetSession, getGetSessionAnalyticsQueryKey, getGetSessionQueryKey } from "@workspace/api-client-react";

const difficultyColor = (d: string) => {
  if (d === "advanced") return "text-red-400";
  if (d === "intermediate") return "text-yellow-400";
  return "text-green-400";
};

export default function Results() {
  const params = useParams<{ sessionId: string }>();
  const sessionId = parseInt(params.sessionId, 10);

  const { data: session, isLoading: sessionLoading } = useGetSession(sessionId, {
    query: { enabled: !!sessionId, queryKey: getGetSessionQueryKey(sessionId) },
  });

  const { data: analytics, isLoading: analyticsLoading } = useGetSessionAnalytics(sessionId, {
    query: { enabled: !!sessionId, queryKey: getGetSessionAnalyticsQueryKey(sessionId) },
  });

  if (sessionLoading || analyticsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!session || !analytics) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-center px-6">
        <AlertCircle className="h-10 w-10 text-muted-foreground mb-3" />
        <p className="text-muted-foreground">Session not found.</p>
        <Link href="/">
          <Button className="mt-4" variant="outline">Go Home</Button>
        </Link>
      </div>
    );
  }

  const progressionData = analytics.scoreProgression.map((score, i) => ({
    q: `Q${i + 1}`,
    score: Math.round(score as number),
  }));

  const topicData = analytics.topicScores.map(t => ({
    topic: t.topic,
    score: Math.round(t.averageScore),
  }));

  return (
    <div className="min-h-screen px-4 py-6 md:px-8">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <div className="flex items-center gap-3 mb-4">
            <Link href="/">
              <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-xl font-bold">Interview Results</h1>
              <p className="text-sm text-muted-foreground">{session.companyName} · {session.roleName}</p>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: "Overall Score", value: `${analytics.overallScore}%`, highlight: true },
              { label: "Confidence", value: `${analytics.confidenceScore}%`, highlight: false },
              { label: "Avg Response", value: `${analytics.averageResponseTime}s`, highlight: false },
              { label: "Questions", value: `${analytics.answeredQuestions}/${analytics.totalQuestions}`, highlight: false },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.08 }}
              >
                <Card className={`border-card-border ${stat.highlight ? "bg-primary/10 border-primary/30" : "bg-card"}`}>
                  <CardContent className="pt-3 pb-2 px-4">
                    <div className="text-xs text-muted-foreground mb-1">{stat.label}</div>
                    <div className={`text-2xl font-bold ${stat.highlight ? "text-primary" : ""}`}>{stat.value}</div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Score Progression */}
        {progressionData.length > 1 && (
          <Card className="bg-card border-card-border mb-4">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Score Progression</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={140}>
                <LineChart data={progressionData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="q" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px" }}
                    labelStyle={{ color: "hsl(var(--foreground))" }}
                  />
                  <Line type="monotone" dataKey="score" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ fill: "hsl(var(--primary))", r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Topic Breakdown */}
        {topicData.length > 0 && (
          <Card className="bg-card border-card-border mb-4">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Topic Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={120}>
                <BarChart data={topicData}>
                  <XAxis dataKey="topic" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px" }}
                  />
                  <Bar dataKey="score" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Strengths & Improvements */}
        <div className="grid sm:grid-cols-2 gap-3 mb-4">
          {analytics.strengths.length > 0 && (
            <Card className="bg-card border-card-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2 text-green-400">
                  <CheckCircle2 className="h-4 w-4" />
                  Strengths
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {analytics.strengths.map((s, i) => (
                    <li key={i} className="text-sm flex gap-2">
                      <span className="text-green-400 shrink-0">•</span>
                      <span className="text-muted-foreground">{s}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}
          {analytics.improvements.length > 0 && (
            <Card className="bg-card border-card-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2 text-yellow-400">
                  <AlertCircle className="h-4 w-4" />
                  Areas to Improve
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {analytics.improvements.map((s, i) => (
                    <li key={i} className="text-sm flex gap-2">
                      <span className="text-yellow-400 shrink-0">•</span>
                      <span className="text-muted-foreground">{s}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Per-question Answers */}
        {session.answers && session.answers.length > 0 && (
          <div className="mb-6">
            <h3 className="text-sm font-semibold text-muted-foreground mb-3 uppercase tracking-wide">Question-by-Question Breakdown</h3>
            <div className="space-y-2">
              {session.answers.map((answer, i) => (
                <motion.div
                  key={answer.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.06 }}
                >
                  <Card className="bg-card border-card-border">
                    <CardContent className="pt-3 pb-3 px-4">
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <div className="flex-1">
                          <p className="text-sm font-medium leading-snug">{answer.questionText}</p>
                          <div className="flex gap-2 mt-1">
                            <Badge variant="outline" className="text-xs capitalize">{answer.topic}</Badge>
                            <Badge variant="outline" className={`text-xs capitalize ${difficultyColor(answer.difficulty)}`}>
                              {answer.difficulty}
                            </Badge>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="text-xl font-bold text-primary">{Math.round(answer.score)}%</div>
                          <div className="text-xs text-muted-foreground">{answer.responseTimeSeconds}s</div>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground border-l-2 border-border pl-2 line-clamp-2">
                        {answer.answerText}
                      </p>
                      {answer.feedback && (
                        <p className="text-xs mt-2 text-primary/80 italic">{answer.feedback}</p>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* CTA */}
        <div className="flex flex-col sm:flex-row gap-3">
          <Link href="/setup" className="flex-1">
            <Button className="w-full gap-2">
              <Play className="h-4 w-4" />
              Start New Interview
            </Button>
          </Link>
          <Link href="/dashboard" className="flex-1">
            <Button variant="outline" className="w-full gap-2">
              <BarChart2 className="h-4 w-4" />
              View Dashboard
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
