import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend,
  ResponsiveContainer, AreaChart, Area
} from "recharts";
import { Play } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useGetProgress } from "@workspace/api-client-react";

function ProgressSkeleton() {
  return (
    <div className="space-y-4">
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <Skeleton className="h-4 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-[220px] w-full rounded-lg" />
        </CardContent>
      </Card>
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <Skeleton className="h-4 w-40" />
        </CardHeader>
        <CardContent className="space-y-3">
          {[0, 1, 2].map(i => (
            <div key={i} className="flex items-center gap-3">
              <Skeleton className="h-3 w-20" />
              <Skeleton className="h-1.5 flex-1 rounded-full" />
              <Skeleton className="h-3 w-10" />
            </div>
          ))}
        </CardContent>
      </Card>
      <div className="space-y-2">
        {[0, 1, 2, 3].map(i => (
          <Card key={i} className="bg-card border-border">
            <CardContent className="py-3 px-4">
              <div className="flex items-center justify-between">
                <div className="space-y-1.5">
                  <Skeleton className="h-4 w-48" />
                  <Skeleton className="h-3 w-24" />
                </div>
                <div className="flex items-center gap-3">
                  <Skeleton className="h-5 w-20 rounded-full" />
                  <Skeleton className="h-8 w-12" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

export default function Progress() {
  const { data: progressData, isLoading, error, refetch } = useGetProgress();

  const chartData = (progressData ?? []).map((p, i) => ({
    session: `#${i + 1}`,
    score: Math.round(p.score),
    confidence: Math.round(p.confidenceScore),
    company: p.company,
    role: p.role,
    date: new Date(p.date).toLocaleDateString(),
    skillLevel: p.skillLevel,
  }));

  const companyMap: Record<string, number[]> = {};
  (progressData ?? []).forEach(p => {
    if (!companyMap[p.company]) companyMap[p.company] = [];
    companyMap[p.company].push(p.score);
  });

  const companyPerf = Object.entries(companyMap).map(([company, scores]) => ({
    company,
    avg: Math.round(scores.reduce((a, b) => a + b, 0) / scores.length),
    sessions: scores.length,
  })).sort((a, b) => b.avg - a.avg);

  const levelColors: Record<string, string> = {
    beginner: "border-green-500/30 text-green-400",
    intermediate: "border-yellow-500/30 text-yellow-400",
    advanced: "border-primary/30 text-primary",
  };

  return (
    <div className="min-h-screen px-4 py-6 md:px-8">
      <div className="max-w-4xl mx-auto">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Progress</h1>
            <p className="text-sm text-muted-foreground">Track your improvement over time</p>
          </div>
          <Link href="/setup">
            <Button size="sm" className="gap-2"><Play className="h-4 w-4" /> New Interview</Button>
          </Link>
        </motion.div>

        {isLoading ? (
          <ProgressSkeleton />
        ) : error ? (
          <Card className="bg-card border-border border-dashed">
            <CardContent className="py-16 text-center">
              <p className="text-muted-foreground text-sm mb-4">Failed to load progress data.</p>
              <Button variant="outline" onClick={() => refetch()}>Try again</Button>
            </CardContent>
          </Card>
        ) : chartData.length === 0 ? (
          <Card className="bg-card border-border border-dashed">
            <CardContent className="py-16 text-center">
              <p className="text-muted-foreground text-sm mb-4">Complete your first interview to see progress charts here.</p>
              <Link href="/setup">
                <Button className="gap-2"><Play className="h-4 w-4" /> Start Interview</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Score & Confidence Chart */}
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}>
              <Card className="bg-card border-border mb-4">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Score & Confidence Over Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={220}>
                    <AreaChart data={chartData} margin={{ left: -20 }}>
                      <defs>
                        <linearGradient id="scoreGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="confGrad" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="hsl(var(--chart-2))" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="hsl(var(--chart-2))" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="session" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} />
                      <YAxis domain={[0, 100]} tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }} />
                      <Tooltip
                        contentStyle={{ backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }}
                        formatter={(value: any, name: string) => [`${value}%`, name]}
                        labelFormatter={(label: string, payload: any[]) => {
                          const item = payload?.[0]?.payload;
                          return item ? `${label} · ${item.company} — ${item.role}` : label;
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: "12px", color: "hsl(var(--muted-foreground))" }} />
                      <Area type="monotone" dataKey="score" name="Score" stroke="hsl(var(--primary))" fill="url(#scoreGrad)" strokeWidth={2} dot={{ r: 4, fill: "hsl(var(--primary))" }} />
                      <Area type="monotone" dataKey="confidence" name="Confidence" stroke="hsl(var(--chart-2))" fill="url(#confGrad)" strokeWidth={2} dot={{ r: 3 }} />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </motion.div>

            {/* Per-Company Performance */}
            {companyPerf.length > 0 && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
                <Card className="bg-card border-border mb-4">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">Performance by Company</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {companyPerf.map(({ company, avg, sessions }, i) => (
                        <div key={company} className="flex items-center gap-3">
                          <div className="w-24 text-xs text-muted-foreground truncate">{company}</div>
                          <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                            <motion.div
                              className="h-full bg-primary rounded-full"
                              initial={{ width: 0 }}
                              animate={{ width: `${avg}%` }}
                              transition={{ delay: i * 0.1 + 0.4, duration: 0.6 }}
                            />
                          </div>
                          <div className="text-xs font-semibold w-10 text-right">{avg}%</div>
                          <div className="text-xs text-muted-foreground w-16 text-right">{sessions}s</div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {/* Session Timeline */}
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}>
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Session Timeline</h3>
              <div className="space-y-2">
                {chartData.map((session, i) => (
                  <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.06 + 0.5 }}>
                    <Card className="bg-card border-border hover:border-primary/30 transition-colors">
                      <CardContent className="py-3 px-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-sm font-medium">{session.company} — {session.role}</div>
                            <div className="text-xs text-muted-foreground">{session.date}</div>
                          </div>
                          <div className="flex items-center gap-3">
                            <Badge variant="outline" className={`capitalize text-xs ${levelColors[session.skillLevel] ?? ""}`}>
                              {session.skillLevel}
                            </Badge>
                            <div className="text-right">
                              <div className="text-base font-bold text-primary">{session.score}%</div>
                              <div className="text-xs text-muted-foreground">conf: {session.confidence}%</div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </>
        )}
      </div>
    </div>
  );
}
