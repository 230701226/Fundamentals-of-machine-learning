import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, RadarChart, Radar,
  PolarGrid, PolarAngleAxis, Cell, LineChart, Line, CartesianGrid
} from "recharts";
import {
  Play, TrendingUp, TrendingDown, Minus, Clock, Search,
  ExternalLink, Film, ShieldCheck
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useGetDashboard, useGetSkillLevel, useGetSessions, useGetProgress, useGetCompanyReadiness
} from "@workspace/api-client-react";

const TrendIcon = ({ trend }: { trend: string }) => {
  if (trend === "improving") return <TrendingUp className="h-3 w-3 text-green-400" />;
  if (trend === "declining") return <TrendingDown className="h-3 w-3 text-red-400" />;
  return <Minus className="h-3 w-3 text-muted-foreground" />;
};

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload?.length) {
    return (
      <div className="bg-card border border-border rounded-lg px-3 py-2 text-xs">
        <p className="text-muted-foreground mb-1">{label}</p>
        {payload.map((p: any) => (
          <p key={p.dataKey} style={{ color: p.color }}>{p.name}: {p.value}%</p>
        ))}
      </div>
    );
  }
  return null;
};

const readinessColor = (level: string) => {
  if (level === "strong") return { bar: "bg-green-500", text: "text-green-400", badge: "border-green-500/30 text-green-400" };
  if (level === "medium") return { bar: "bg-yellow-500", text: "text-yellow-400", badge: "border-yellow-500/30 text-yellow-400" };
  return { bar: "bg-red-500", text: "text-red-400", badge: "border-red-500/30 text-red-400" };
};

function DashboardSkeleton() {
  return (
    <div className="min-h-screen px-4 py-6 md:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="space-y-1.5">
            <Skeleton className="h-7 w-32" />
            <Skeleton className="h-4 w-48" />
          </div>
          <Skeleton className="h-8 w-28 rounded-md" />
        </div>
        {/* Skill level banner */}
        <Skeleton className="h-24 w-full rounded-xl mb-4" />
        {/* Stats grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
          {[0,1,2,3].map(i => (
            <Card key={i} className="bg-card border-border">
              <CardContent className="pt-3 pb-2 px-4 space-y-2">
                <Skeleton className="h-3 w-16" />
                <Skeleton className="h-7 w-12" />
              </CardContent>
            </Card>
          ))}
        </div>
        {/* Improvement rate */}
        <Skeleton className="h-14 w-full rounded-xl mb-4" />
        {/* Charts */}
        <div className="grid md:grid-cols-2 gap-4 mb-4">
          <Card className="bg-card border-border">
            <CardHeader className="pb-2"><Skeleton className="h-4 w-24" /></CardHeader>
            <CardContent><Skeleton className="h-[180px] w-full rounded-lg" /></CardContent>
          </Card>
          <Card className="bg-card border-border">
            <CardHeader className="pb-2"><Skeleton className="h-4 w-20" /></CardHeader>
            <CardContent><Skeleton className="h-[180px] w-full rounded-lg" /></CardContent>
          </Card>
        </div>
        {/* Session list */}
        <div className="space-y-2">
          {[0,1,2,3].map(i => (
            <Card key={i} className="bg-card border-border">
              <CardContent className="py-3 px-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1.5">
                    <Skeleton className="h-4 w-52" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                  <div className="flex items-center gap-2">
                    <Skeleton className="h-5 w-12 rounded-full" />
                    <Skeleton className="h-7 w-7 rounded-md" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { data: dashboard, isLoading } = useGetDashboard();
  const { data: skillLevel } = useGetSkillLevel();
  const { data: allSessions } = useGetSessions();
  const { data: progress } = useGetProgress();
  const { data: companyReadiness } = useGetCompanyReadiness();
  const [sessionSearch, setSessionSearch] = useState("");
  const [showAllSessions, setShowAllSessions] = useState(false);

  if (isLoading) return <DashboardSkeleton />;
  if (!dashboard) return null;

  const topicChartData = dashboard.topicBreakdown.map(t => ({
    topic: t.topic.charAt(0).toUpperCase() + t.topic.slice(1),
    score: Math.round(t.averageScore),
    full: t.topic,
    trend: t.trend,
    questions: t.questionsAnswered,
  }));

  const radarData = dashboard.topicBreakdown.map(t => ({
    subject: t.topic.charAt(0).toUpperCase() + t.topic.slice(1),
    A: Math.round(t.averageScore),
    fullMark: 100,
  }));

  const trendData = (progress ?? []).map((p, i) => ({
    session: `#${i + 1}`,
    score: Math.round(p.score as number),
    confidence: Math.round(p.confidenceScore as number),
    label: `${p.company} — ${p.role}`,
  }));

  const filteredSessions = (allSessions ?? []).filter(s =>
    !sessionSearch ||
    s.companyName?.toLowerCase().includes(sessionSearch.toLowerCase()) ||
    s.roleName?.toLowerCase().includes(sessionSearch.toLowerCase())
  );
  const displayedSessions = showAllSessions ? filteredSessions : filteredSessions.slice(0, 8);

  return (
    <div className="min-h-screen px-4 py-6 md:px-8">
      <div className="max-w-4xl mx-auto">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Dashboard</h1>
            <p className="text-sm text-muted-foreground">Your performance overview</p>
          </div>
          <Link href="/setup">
            <Button size="sm" className="gap-2">
              <Play className="h-4 w-4" />
              New Interview
            </Button>
          </Link>
        </motion.div>

        {/* Skill Level Banner */}
        {skillLevel && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}>
            <Card className="mb-4 bg-primary/10 border-primary/30">
              <CardContent className="py-4 px-5">
                <div className="flex items-center justify-between flex-wrap gap-3">
                  <div className="flex items-center gap-4 flex-wrap">
                    <div>
                      <div className="text-xs text-muted-foreground mb-0.5">Skill Level</div>
                      <span className="text-xl font-bold capitalize text-primary">{skillLevel.level}</span>
                    </div>
                    <div className="min-w-[120px]">
                      <div className="h-1.5 bg-primary/20 rounded-full overflow-hidden">
                        <motion.div
                          className="h-full bg-primary rounded-full"
                          initial={{ width: 0 }}
                          animate={{ width: `${skillLevel.percentToNextLevel}%` }}
                          transition={{ duration: 0.8, ease: "easeOut" }}
                        />
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5">{skillLevel.percentToNextLevel}% to next level</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-muted-foreground">Avg Score</div>
                    <div className="text-3xl font-bold">{skillLevel.score}%</div>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-3 border-t border-primary/20 pt-2">{skillLevel.nextLevelRequirements}</p>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
          {[
            { label: "Sessions", value: dashboard.totalSessions },
            { label: "Completed", value: dashboard.completedSessions },
            { label: "Questions", value: dashboard.totalQuestionsAnswered },
            { label: "Avg Response", value: `${dashboard.averageResponseTime}s` },
          ].map((stat, i) => (
            <motion.div key={stat.label} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08 + 0.2 }}>
              <Card className="bg-card border-border">
                <CardContent className="pt-3 pb-2 px-4">
                  <div className="text-xs text-muted-foreground mb-1">{stat.label}</div>
                  <div className="text-2xl font-bold">{stat.value}</div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Improvement Rate */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="mb-4">
          <Card className={`border ${dashboard.improvementRate >= 0 ? "bg-green-500/5 border-green-500/20" : "bg-red-500/5 border-red-500/20"}`}>
            <CardContent className="py-3 px-5 flex items-center justify-between">
              <div>
                <div className="text-xs text-muted-foreground">Improvement Rate (recent vs prior sessions)</div>
                <div className={`text-xl font-bold ${dashboard.improvementRate >= 0 ? "text-green-400" : "text-red-400"}`}>
                  {dashboard.improvementRate >= 0 ? "+" : ""}{dashboard.improvementRate}%
                </div>
              </div>
              {dashboard.improvementRate >= 0
                ? <TrendingUp className="h-8 w-8 text-green-400 opacity-50" />
                : <TrendingDown className="h-8 w-8 text-red-400 opacity-50" />}
            </CardContent>
          </Card>
        </motion.div>

        {/* Score Trend */}
        {trendData.length >= 2 && (
          <Card className="bg-card border-border mb-4">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Score Trend Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={160}>
                <LineChart data={trendData} margin={{ left: -20, right: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="session" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }} />
                  <Tooltip content={<CustomTooltip />} />
                  <Line type="monotone" dataKey="score" name="Quality" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ fill: "hsl(var(--primary))", r: 3 }} />
                  <Line type="monotone" dataKey="confidence" name="Confidence" stroke="hsl(var(--chart-3))" strokeWidth={1.5} strokeDasharray="4 4" dot={{ fill: "hsl(var(--chart-3))", r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Charts Row */}
        <div className="grid md:grid-cols-2 gap-4 mb-4">
          {topicChartData.length > 0 && (
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Topic Scores</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={180}>
                  <BarChart data={topicChartData} margin={{ left: -20 }}>
                    <XAxis dataKey="topic" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }} />
                    <YAxis domain={[0, 100]} tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }} />
                    <Tooltip contentStyle={{ backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "8px", fontSize: "12px" }} />
                    <Bar dataKey="score" radius={[4, 4, 0, 0]}>
                      {topicChartData.map((entry, i) => (
                        <Cell key={i} fill={entry.score >= 72 ? "hsl(var(--primary))" : entry.score >= 50 ? "hsl(40 90% 55%)" : "hsl(var(--destructive))"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}

          {radarData.length >= 3 && (
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Skill Radar</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={180}>
                  <RadarChart data={radarData}>
                    <PolarGrid stroke="hsl(var(--border))" />
                    <PolarAngleAxis dataKey="subject" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }} />
                    <Radar name="Score" dataKey="A" stroke="hsl(var(--primary))" fill="hsl(var(--primary))" fillOpacity={0.25} />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Topic Breakdown */}
        {topicChartData.length > 0 && (
          <Card className="bg-card border-border mb-4">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Topic Breakdown</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2.5">
                {topicChartData.sort((a, b) => a.score - b.score).map((topic, i) => (
                  <div key={topic.full} className="flex items-center gap-3">
                    <div className="w-28 text-xs text-muted-foreground capitalize truncate">{topic.full}</div>
                    <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                      <motion.div
                        className="h-full rounded-full"
                        style={{ backgroundColor: topic.score >= 72 ? "hsl(var(--primary))" : topic.score >= 50 ? "hsl(40 90% 55%)" : "hsl(var(--destructive))" }}
                        initial={{ width: 0 }}
                        animate={{ width: `${topic.score}%` }}
                        transition={{ delay: i * 0.08 + 0.5, duration: 0.6 }}
                      />
                    </div>
                    <div className="text-xs font-semibold w-9 text-right">{topic.score}%</div>
                    <div className="text-xs text-muted-foreground w-10 text-right">{topic.questions}q</div>
                    <TrendIcon trend={topic.trend} />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Company Readiness */}
        {companyReadiness && companyReadiness.length > 0 && (
          <Card className="bg-card border-border mb-4">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-primary" />
                Company Readiness
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {companyReadiness.map((cr, i) => {
                  const colors = readinessColor(cr.readinessLevel);
                  return (
                    <motion.div key={cr.companyId} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.1 }}>
                      <div className="flex items-center justify-between mb-1.5">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium">{cr.companyName}</span>
                          <Badge variant="outline" className={`text-xs capitalize ${colors.badge}`}>{cr.readinessLevel}</Badge>
                        </div>
                        <span className={`text-sm font-bold ${colors.text}`}>{Math.round(cr.readinessScore)}%</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <motion.div
                          className={`h-full rounded-full ${colors.bar}`}
                          initial={{ width: 0 }}
                          animate={{ width: `${cr.readinessScore}%` }}
                          transition={{ delay: i * 0.1 + 0.3, duration: 0.7 }}
                        />
                      </div>
                      {cr.topicBreakdown.length > 0 && (
                        <div className="flex gap-2 mt-1.5 flex-wrap">
                          {cr.topicBreakdown.slice(0, 4).map(t => (
                            <span key={t.topic} className="text-xs text-muted-foreground">
                              {t.topic}: <span className={t.averageScore >= 70 ? "text-green-400" : t.averageScore >= 50 ? "text-yellow-400" : "text-red-400"}>{Math.round(t.averageScore)}%</span>
                            </span>
                          ))}
                        </div>
                      )}
                    </motion.div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Session History */}
        {(allSessions ?? []).length > 0 && (
          <div className="mb-6">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Session History</h3>
              <div className="relative w-48">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input
                  value={sessionSearch}
                  onChange={(e) => setSessionSearch(e.target.value)}
                  placeholder="Filter sessions..."
                  className="h-7 pl-8 text-xs bg-background"
                />
              </div>
            </div>
            <div className="space-y-2">
              {displayedSessions.map((s, i) => (
                <motion.div key={s.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.05 + 0.3 }}>
                  <Card className="bg-card border-border hover:border-primary/40 transition-colors">
                    <CardContent className="py-3 px-4">
                      <div className="flex items-center justify-between gap-2">
                        <div className="min-w-0">
                          <div className="text-sm font-medium truncate">{s.companyName} — {s.roleName}</div>
                          <div className="flex items-center gap-3 mt-0.5 flex-wrap">
                            <span className="text-xs text-muted-foreground flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              {new Date(s.createdAt).toLocaleDateString()}
                            </span>
                            <span className="text-xs text-muted-foreground">{s.answeredQuestions} questions</span>
                            <span className="text-xs text-muted-foreground capitalize">{s.interviewType}</span>
                            {s.mode === "stress" && (
                              <Badge variant="outline" className="text-xs border-red-500/30 text-red-400 h-4">Stress</Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          {s.overallScore != null && (
                            <span className={`text-base font-bold ${(s.overallScore as number) >= 72 ? "text-green-400" : (s.overallScore as number) >= 50 ? "text-yellow-400" : "text-red-400"}`}>
                              {Math.round(s.overallScore as number)}%
                            </span>
                          )}
                          <Badge variant="outline" className={`capitalize text-xs ${s.status === "completed" ? "border-green-500/30 text-green-400" : "border-yellow-500/30 text-yellow-400"}`}>
                            {s.status}
                          </Badge>
                          {s.status === "completed" && s.answeredQuestions > 0 && (
                            <Link href={`/replay/${s.id}`}>
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-primary" title="Replay session">
                                <Film className="h-3.5 w-3.5" />
                              </Button>
                            </Link>
                          )}
                          <Link href={`/results/${s.id}`}>
                            <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-primary">
                              <ExternalLink className="h-3.5 w-3.5" />
                            </Button>
                          </Link>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>

            {filteredSessions.length > 8 && (
              <div className="text-center mt-3">
                <Button variant="ghost" size="sm" onClick={() => setShowAllSessions(!showAllSessions)} className="text-primary text-xs">
                  {showAllSessions ? "Show less" : `Show all ${filteredSessions.length} sessions`}
                </Button>
              </div>
            )}
          </div>
        )}

        {dashboard.totalSessions === 0 && (
          <Card className="bg-card border-border border-dashed">
            <CardContent className="py-14 text-center">
              <p className="text-muted-foreground text-sm mb-4">
                No interview sessions yet. Start your first interview to see analytics here.
              </p>
              <Link href="/setup">
                <Button className="gap-2">
                  <Play className="h-4 w-4" />
                  Start Interview
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
