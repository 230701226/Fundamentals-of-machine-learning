import { motion } from "framer-motion";
import { Link } from "wouter";
import { AlertTriangle, Lightbulb, Play, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { useGetWeakAreas } from "@workspace/api-client-react";

const priorityConfig = {
  high: { color: "border-red-500/30 text-red-400 bg-red-500/10", label: "High Priority" },
  medium: { color: "border-yellow-500/30 text-yellow-400 bg-yellow-500/10", label: "Medium Priority" },
  low: { color: "border-green-500/30 text-green-400 bg-green-500/10", label: "Low Priority" },
};

function WeakAreaSkeleton() {
  return (
    <Card className="bg-card border-border">
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Skeleton className="h-5 w-28" />
            <Skeleton className="h-5 w-20 rounded-full" />
          </div>
          <div className="text-right space-y-1">
            <Skeleton className="h-8 w-12 ml-auto" />
            <Skeleton className="h-3 w-20 ml-auto" />
          </div>
        </div>
        <Skeleton className="h-1.5 w-full mt-2 rounded-full" />
      </CardHeader>
      <CardContent className="space-y-2">
        <Skeleton className="h-4 w-full" />
        <Skeleton className="h-4 w-5/6" />
        <Skeleton className="h-4 w-4/5" />
      </CardContent>
    </Card>
  );
}

export default function WeakAreas() {
  const { data: weakAreas, isLoading, error, refetch } = useGetWeakAreas();

  return (
    <div className="min-h-screen px-4 py-6 md:px-8">
      <div className="max-w-3xl mx-auto">
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold">Weak Areas</h1>
            <p className="text-sm text-muted-foreground">Focus here for maximum improvement</p>
          </div>
          <Link href="/setup">
            <Button size="sm" className="gap-2"><Play className="h-4 w-4" /> Practice</Button>
          </Link>
        </motion.div>

        {isLoading ? (
          <div className="space-y-4">
            {[0, 1, 2].map(i => <WeakAreaSkeleton key={i} />)}
          </div>
        ) : error ? (
          <Card className="bg-card border-border border-dashed">
            <CardContent className="py-16 text-center">
              <p className="text-muted-foreground text-sm mb-4">Failed to load weak areas.</p>
              <Button variant="outline" onClick={() => refetch()}>Try again</Button>
            </CardContent>
          </Card>
        ) : !weakAreas || weakAreas.length === 0 ? (
          <Card className="bg-card border-border border-dashed">
            <CardContent className="py-16 text-center">
              <CheckCircle className="h-12 w-12 text-green-400 mx-auto mb-4 opacity-60" />
              <h3 className="font-semibold text-lg mb-2">No weak areas detected</h3>
              <p className="text-muted-foreground text-sm mb-6 max-w-sm mx-auto">
                Complete more interview sessions so the system can identify areas for improvement.
              </p>
              <Link href="/setup">
                <Button className="gap-2"><Play className="h-4 w-4" /> Start Interview</Button>
              </Link>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Priority summary */}
            <div className="flex gap-2 mb-6 flex-wrap">
              {(["high", "medium", "low"] as const).map(priority => {
                const count = weakAreas.filter(wa => wa.priority === priority).length;
                if (count === 0) return null;
                const config = priorityConfig[priority];
                return (
                  <div key={priority} className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-medium ${config.color}`}>
                    <AlertTriangle className="h-3.5 w-3.5" />
                    {count} {config.label}
                  </div>
                );
              })}
            </div>

            <div className="space-y-4">
              {weakAreas.map((area, i) => {
                const config = priorityConfig[area.priority as keyof typeof priorityConfig];
                const scoreColor = area.averageScore < 40 ? "text-red-400" : area.averageScore < 60 ? "text-yellow-400" : "text-muted-foreground";
                const barColor = area.averageScore < 40 ? "bg-red-500" : area.averageScore < 60 ? "bg-yellow-500" : "bg-primary";

                return (
                  <motion.div key={area.topic} initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.1 }}>
                    <Card className="bg-card border-border">
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <CardTitle className="text-base capitalize">{area.topic}</CardTitle>
                            <Badge variant="outline" className={`text-xs ${config.color}`}>{area.priority}</Badge>
                          </div>
                          <div className="text-right">
                            <div className={`text-2xl font-bold ${scoreColor}`}>{area.averageScore}%</div>
                            <div className="text-xs text-muted-foreground">{area.questionsAttempted} question{area.questionsAttempted !== 1 ? "s" : ""}</div>
                          </div>
                        </div>
                        <div className="mt-2 h-1.5 bg-muted rounded-full overflow-hidden">
                          <motion.div
                            className={`h-full rounded-full ${barColor}`}
                            initial={{ width: 0 }}
                            animate={{ width: `${area.averageScore}%` }}
                            transition={{ delay: i * 0.1 + 0.3, duration: 0.6 }}
                          />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="flex items-start gap-2 mb-3">
                          <Lightbulb className="h-4 w-4 text-yellow-400 shrink-0 mt-0.5" />
                          <h4 className="text-sm font-medium text-yellow-400">Improvement Suggestions</h4>
                        </div>
                        <ul className="space-y-2">
                          {area.suggestions.map((suggestion, si) => (
                            <li key={si} className="flex gap-2 text-sm text-muted-foreground">
                              <span className="text-primary shrink-0 mt-0.5">→</span>{suggestion}
                            </li>
                          ))}
                        </ul>
                        <div className="mt-4 flex justify-end">
                          <Link href="/setup">
                            <Button size="sm" variant="outline" className="text-xs gap-1.5">
                              Practice {area.topic} <Play className="h-3 w-3" />
                            </Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                );
              })}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
