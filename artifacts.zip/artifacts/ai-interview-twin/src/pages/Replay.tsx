import { useParams, Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, ArrowRight, CheckCircle2, XCircle, Clock, AlertCircle, Loader2, BarChart2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useState } from "react";
import { useGetSessionReplay, getGetSessionReplayQueryKey } from "@workspace/api-client-react";
import {
  LineChart, Line, ResponsiveContainer, Tooltip, YAxis, XAxis, CartesianGrid
} from "recharts";

export default function Replay() {
  const params = useParams<{ sessionId: string }>();
  const sessionId = parseInt(params.sessionId, 10);
  const [currentIdx, setCurrentIdx] = useState(0);

  const { data: replay, isLoading, error } = useGetSessionReplay(sessionId, {
    query: { enabled: !!sessionId, queryKey: getGetSessionReplayQueryKey(sessionId) },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !replay) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-center px-6">
        <AlertCircle className="h-10 w-10 text-muted-foreground mb-3" />
        <p className="text-muted-foreground text-sm mb-4">Session not found.</p>
        <Link href="/dashboard"><Button variant="outline">Go to Dashboard</Button></Link>
      </div>
    );
  }

  if (replay.answers.length === 0) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-center px-6">
        <AlertCircle className="h-10 w-10 text-muted-foreground mb-3" />
        <p className="text-muted-foreground text-sm mb-4">No answers recorded in this session.</p>
        <Link href="/dashboard"><Button variant="outline">Go to Dashboard</Button></Link>
      </div>
    );
  }

  const answer = replay.answers[currentIdx];
  const total = replay.answers.length;

  const chartData = replay.answers.map((a, i) => ({
    q: `Q${i + 1}`,
    score: a.score,
    conf: a.confidenceScore,
  }));

  const scoreColor = (s: number) => s >= 75 ? "text-green-400" : s >= 50 ? "text-yellow-400" : "text-red-400";
  const difficultyColor = (d: string) => d === "advanced" ? "border-red-500/30 text-red-400" : d === "intermediate" ? "border-yellow-500/30 text-yellow-400" : "border-green-500/30 text-green-400";

  return (
    <div className="min-h-screen px-4 py-6 md:px-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-6">
          <div className="flex items-center gap-3 mb-4">
            <Link href={`/results/${sessionId}`}>
              <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-xl font-bold">Session Replay</h1>
              <p className="text-sm text-muted-foreground">{replay.companyName} · {replay.roleName}</p>
            </div>
            <div className="ml-auto flex items-center gap-2">
              {replay.overallScore != null && (
                <span className={`text-lg font-bold ${scoreColor(replay.overallScore)}`}>{Math.round(replay.overallScore)}%</span>
              )}
              <Link href={`/results/${sessionId}`}>
                <Button variant="outline" size="sm" className="gap-1.5 text-xs">
                  <BarChart2 className="h-3.5 w-3.5" />
                  Full Results
                </Button>
              </Link>
            </div>
          </div>

          {/* Score progression chart */}
          {chartData.length >= 2 && (
            <Card className="bg-card border-border mb-4">
              <CardHeader className="pb-1 pt-3">
                <CardTitle className="text-xs text-muted-foreground font-normal">Score Progression — click a bar to jump to that question</CardTitle>
              </CardHeader>
              <CardContent className="pb-3">
                <ResponsiveContainer width="100%" height={80}>
                  <LineChart data={chartData} onClick={(e) => { if (e?.activeTooltipIndex != null) setCurrentIdx(e.activeTooltipIndex); }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="q" tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 10 }} />
                    <YAxis domain={[0, 100]} hide />
                    <Tooltip contentStyle={{ fontSize: "11px", backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "6px" }} formatter={(v: any, name: string) => [`${v}%`, name === "score" ? "Quality" : "Confidence"]} />
                    <Line type="monotone" dataKey="score" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ fill: "hsl(var(--primary))", r: 3, cursor: "pointer" }} activeDot={{ r: 5 }} />
                    <Line type="monotone" dataKey="conf" stroke="hsl(var(--chart-3))" strokeWidth={1.5} strokeDasharray="4 4" dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}

          {/* Navigation */}
          <div className="flex items-center justify-between mb-4">
            <Button variant="outline" size="sm" onClick={() => setCurrentIdx(Math.max(0, currentIdx - 1))} disabled={currentIdx === 0} className="gap-1.5">
              <ArrowLeft className="h-3.5 w-3.5" /> Previous
            </Button>
            <div className="flex items-center gap-2">
              {replay.answers.map((a, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentIdx(i)}
                  className={`h-2 w-2 rounded-full transition-all ${i === currentIdx ? "bg-primary scale-150" : a.score >= 70 ? "bg-green-500/50" : a.score >= 50 ? "bg-yellow-500/50" : "bg-red-500/50"}`}
                />
              ))}
            </div>
            <Button variant="outline" size="sm" onClick={() => setCurrentIdx(Math.min(total - 1, currentIdx + 1))} disabled={currentIdx === total - 1} className="gap-1.5">
              Next <ArrowRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </motion.div>

        {/* Answer card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIdx}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            transition={{ duration: 0.25 }}
          >
            <div className="flex items-center gap-2 mb-3">
              <span className="text-xs font-mono text-muted-foreground">Q{answer.questionNumber} / {total}</span>
              <Badge variant="outline" className="text-xs capitalize">{answer.topic}</Badge>
              <Badge variant="outline" className={`text-xs capitalize ${difficultyColor(answer.difficulty)}`}>{answer.difficulty}</Badge>
              <div className="ml-auto flex items-center gap-1 text-xs text-muted-foreground">
                <Clock className="h-3 w-3" />
                {Math.round(answer.responseTimeSeconds)}s
              </div>
            </div>

            {/* Question */}
            <Card className="bg-card border-border mb-3">
              <CardContent className="py-4 px-4">
                <p className="text-sm font-medium leading-relaxed">{answer.questionText}</p>
              </CardContent>
            </Card>

            {/* Answer */}
            <Card className="bg-muted/30 border-border mb-3">
              <CardHeader className="pb-1 pt-3">
                <CardTitle className="text-xs text-muted-foreground font-normal">Your Answer</CardTitle>
              </CardHeader>
              <CardContent className="pb-4 px-4">
                <p className="text-sm leading-relaxed text-foreground">{answer.answerText}</p>
              </CardContent>
            </Card>

            {/* Scores */}
            <div className="grid grid-cols-2 gap-3 mb-3">
              <Card className="bg-card border-border">
                <CardContent className="pt-3 pb-2 px-4">
                  <div className="text-xs text-muted-foreground mb-1">Answer Quality</div>
                  <div className={`text-2xl font-bold ${scoreColor(answer.score)}`}>{answer.score}%</div>
                  <Progress value={answer.score} className="mt-2 h-1" />
                </CardContent>
              </Card>
              <Card className="bg-card border-border">
                <CardContent className="pt-3 pb-2 px-4">
                  <div className="text-xs text-muted-foreground mb-1">Confidence</div>
                  <div className="text-2xl font-bold text-primary">{answer.confidenceScore}%</div>
                  <Progress value={answer.confidenceScore} className="mt-2 h-1" />
                </CardContent>
              </Card>
            </div>

            {/* Feedback */}
            {answer.feedback && (
              <Card className="bg-card border-border mb-3">
                <CardContent className="py-3 px-4">
                  <div className="flex items-start gap-2">
                    {answer.score >= 70 ? <CheckCircle2 className="h-4 w-4 text-green-400 shrink-0 mt-0.5" /> : <XCircle className="h-4 w-4 text-yellow-400 shrink-0 mt-0.5" />}
                    <p className="text-sm leading-relaxed">{answer.feedback}</p>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Navigation footer */}
            <div className="flex gap-3 mt-4">
              <Button variant="outline" className="flex-1 gap-2" onClick={() => setCurrentIdx(Math.max(0, currentIdx - 1))} disabled={currentIdx === 0}>
                <ArrowLeft className="h-4 w-4" /> Previous
              </Button>
              {currentIdx < total - 1 ? (
                <Button className="flex-1 gap-2" onClick={() => setCurrentIdx(currentIdx + 1)}>
                  Next <ArrowRight className="h-4 w-4" />
                </Button>
              ) : (
                <Link href={`/results/${sessionId}`} className="flex-1">
                  <Button className="w-full gap-2">
                    <BarChart2 className="h-4 w-4" /> Full Analysis
                  </Button>
                </Link>
              )}
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
