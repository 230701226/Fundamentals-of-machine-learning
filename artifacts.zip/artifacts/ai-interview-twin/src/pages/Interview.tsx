import { useState, useEffect, useRef, useCallback } from "react";
import { useParams, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  Send, Mic, MicOff, Clock, ChevronRight, Check, X, Lightbulb,
  BarChart2, AlertCircle, Loader2, BrainCircuit, CheckCircle2,
  Radio, WifiOff, TrendingUp, TrendingDown, Zap, MessageSquare, Activity
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import {
  LineChart, Line, ResponsiveContainer, Tooltip, YAxis,
} from "recharts";
import {
  useGetSession,
  useGetNextQuestion,
  useSubmitAnswer,
  useUpdateSession,
  getGetSessionQueryKey,
  getGetNextQuestionQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

const STRESS_TIME_LIMIT = 45;

type EvaluationResult = {
  score: number;
  confidenceScore: number;
  feedback: string;
  strengths: string[];
  improvements: string[];
  keywordMatches: string[];
  difficultyAdjustment: string;
  followUpQuestion?: string | null;
  interviewerStyle?: string | null;
};

type VoiceStatus = "idle" | "listening" | "error" | "unsupported";

const INTERVIEWER_STYLE_LABEL: Record<string, string> = {
  strict: "Strict — High-bar, no-fluff",
  analytical: "Analytical — Data-driven, deep-dive",
  collaborative: "Collaborative — Growth mindset",
  "impact-driven": "Impact-driven — Move fast",
  friendly: "Friendly — Process-oriented",
  "process-driven": "Process-driven — Methodology",
  structured: "Structured — Agile delivery",
  technical: "Technical — Product thinking",
};

export default function Interview() {
  const params = useParams<{ sessionId: string }>();
  const sessionId = parseInt(params.sessionId, 10);
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [answerText, setAnswerText] = useState("");
  const [interimText, setInterimText] = useState("");
  const [voiceStatus, setVoiceStatus] = useState<VoiceStatus>("idle");
  const [startTime, setStartTime] = useState<number>(Date.now());
  const [elapsed, setElapsed] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(STRESS_TIME_LIMIT);
  const [showHints, setShowHints] = useState(false);
  const [evaluation, setEvaluation] = useState<EvaluationResult | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [isFinished, setIsFinished] = useState(false);
  const [voiceFallback, setVoiceFallback] = useState(false);
  const [scoreHistory, setScoreHistory] = useState<{ q: number; score: number; conf: number }[]>([]);
  const [showFollowUp, setShowFollowUp] = useState(false);

  const recognitionRef = useRef<any>(null);
  const answerRef = useRef(answerText);
  answerRef.current = answerText;

  const { data: session, isLoading: sessionLoading } = useGetSession(sessionId, {
    query: { enabled: !!sessionId, queryKey: getGetSessionQueryKey(sessionId) },
  });

  const { data: question, isLoading: questionLoading, error: questionError } = useGetNextQuestion(sessionId, {
    query: { enabled: !!sessionId && !isFinished, queryKey: getGetNextQuestionQueryKey(sessionId) },
  });

  const submitAnswer = useSubmitAnswer();
  const updateSession = useUpdateSession();

  const isStressMode = session?.mode === "stress";

  useEffect(() => {
    setStartTime(Date.now());
    setElapsed(0);
    setTimeRemaining(STRESS_TIME_LIMIT);
    setInterimText("");
    setShowFollowUp(false);
  }, [question?.id]);

  // Elapsed timer
  useEffect(() => {
    if (submitted) return;
    const interval = setInterval(() => setElapsed(Math.floor((Date.now() - startTime) / 1000)), 1000);
    return () => clearInterval(interval);
  }, [startTime, submitted]);

  // Stress mode countdown
  useEffect(() => {
    if (!isStressMode || submitted || !question) return;
    setTimeRemaining(STRESS_TIME_LIMIT);
    const interval = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev <= 1) {
          clearInterval(interval);
          // Auto-submit with whatever text is entered
          const currentAnswer = answerRef.current.trim() || "[No answer provided — time expired]";
          submitAnswer.mutateAsync({
            sessionId,
            data: { questionId: question.id, answerText: currentAnswer, responseTimeSeconds: STRESS_TIME_LIMIT },
          }).then(result => {
            setEvaluation(result as EvaluationResult);
            setSubmitted(true);
            setScoreHistory(prev => [...prev, { q: prev.length + 1, score: result.score, conf: result.confidenceScore }]);
            queryClient.invalidateQueries({ queryKey: getGetSessionQueryKey(sessionId) });
          }).catch(() => {});
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [question?.id, isStressMode, submitted]);

  const stopRecording = useCallback(() => {
    if (recognitionRef.current) { recognitionRef.current.stop(); recognitionRef.current = null; }
    setVoiceStatus("idle");
    setInterimText("");
  }, []);

  const startRecording = useCallback(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setVoiceStatus("unsupported");
      setVoiceFallback(true);
      toast({ title: "Voice not supported", description: "Using text mode instead.", variant: "destructive" });
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = "en-US";
    let finalTranscript = answerText;

    recognition.onresult = (event: any) => {
      let interim = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        if (event.results[i].isFinal) {
          finalTranscript += (finalTranscript ? " " : "") + event.results[i][0].transcript.trim();
          setAnswerText(finalTranscript);
          setInterimText("");
        } else {
          interim += event.results[i][0].transcript;
          setInterimText(interim);
        }
      }
    };

    recognition.onerror = (event: any) => {
      const errMsg: Record<string, string> = {
        "not-allowed": "Microphone access denied.",
        "no-speech": "No speech detected.",
        "network": "Network error during recognition.",
      };
      const msg = errMsg[event.error];
      if (msg) { toast({ title: "Microphone error", description: msg, variant: "destructive" }); }
      if (event.error === "not-allowed") setVoiceFallback(true);
      setVoiceStatus("error");
      setInterimText("");
    };

    recognition.onend = () => { setVoiceStatus("idle"); setInterimText(""); };
    recognitionRef.current = recognition;
    recognition.start();
    setVoiceStatus("listening");
  }, [answerText, toast]);

  const toggleRecording = useCallback(() => {
    voiceStatus === "listening" ? stopRecording() : startRecording();
  }, [voiceStatus, stopRecording, startRecording]);

  const handleSubmit = async () => {
    if (!question || !answerText.trim()) return;
    if (voiceStatus === "listening") stopRecording();
    const responseTime = Math.max(1, elapsed);
    try {
      const result = await submitAnswer.mutateAsync({
        sessionId,
        data: { questionId: question.id, answerText: answerText.trim(), responseTimeSeconds: responseTime },
      });
      setEvaluation(result as EvaluationResult);
      setSubmitted(true);
      setScoreHistory(prev => [...prev, { q: prev.length + 1, score: result.score, conf: result.confidenceScore }]);
      queryClient.invalidateQueries({ queryKey: getGetSessionQueryKey(sessionId) });
      const grade = result.score >= 75 ? "Excellent" : result.score >= 55 ? "Good" : "Needs work";
      toast({ title: `${grade} — ${result.score}% quality`, description: result.feedback.slice(0, 80) + (result.feedback.length > 80 ? "..." : "") });
    } catch {
      toast({ title: "Submission failed", description: "Please try again.", variant: "destructive" });
    }
  };

  const handleNextQuestion = () => {
    if (session && (session.answeredQuestions + 1) >= session.totalQuestions) {
      setIsFinished(true);
      return;
    }
    setAnswerText("");
    setInterimText("");
    setEvaluation(null);
    setSubmitted(false);
    setShowHints(false);
    setShowFollowUp(false);
    queryClient.invalidateQueries({ queryKey: getGetNextQuestionQueryKey(sessionId) });
  };

  const handleFinish = async () => {
    await updateSession.mutateAsync({ sessionId, data: { status: "completed" } });
    navigate(`/results/${sessionId}`);
  };

  const formatTime = (s: number) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;
  const wordCount = answerText.split(/\s+/).filter(Boolean).length;
  const isVoiceMode = session?.interviewType === "voice" && !voiceFallback;
  const stressUrgent = isStressMode && !submitted && timeRemaining <= 15;
  const stressWarning = isStressMode && !submitted && timeRemaining <= 25;

  if (sessionLoading) return <div className="min-h-screen flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;

  if (isFinished) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center">
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} transition={{ type: "spring", stiffness: 200 }}>
          <div className="h-20 w-20 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="h-10 w-10 text-primary" />
          </div>
          <h2 className="text-2xl font-bold mb-2">Interview Complete</h2>
          <p className="text-muted-foreground mb-6 max-w-sm">You answered {session?.answeredQuestions ?? 0} questions. View your detailed feedback and results.</p>
          {scoreHistory.length >= 2 && (
            <div className="mb-6 w-full max-w-xs mx-auto">
              <p className="text-xs text-muted-foreground mb-2">Score progression</p>
              <ResponsiveContainer width="100%" height={60}>
                <LineChart data={scoreHistory}>
                  <Line type="monotone" dataKey="score" stroke="hsl(var(--primary))" strokeWidth={2} dot={false} />
                  <YAxis domain={[0, 100]} hide />
                  <Tooltip contentStyle={{ fontSize: "11px", backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "6px" }} formatter={(v: any) => [`${v}%`, "Score"]} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
          <Button size="lg" onClick={handleFinish} disabled={updateSession.isPending} className="gap-2">
            {updateSession.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <BarChart2 className="h-4 w-4" />}
            View Results
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen px-4 py-5 md:px-8 md:py-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 min-w-0">
            <BrainCircuit className="h-4 w-4 text-primary shrink-0" />
            <span className="font-semibold text-sm truncate">{session?.companyName} — {session?.roleName}</span>
            {isStressMode && <Badge variant="outline" className="text-xs border-red-500/40 text-red-400 bg-red-500/10 shrink-0"><Zap className="h-3 w-3 mr-1 inline" />Stress</Badge>}
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Badge variant="outline" className="text-xs capitalize hidden sm:flex">{session?.skillLevel}</Badge>
            <div className={`flex items-center gap-1 text-sm font-mono ${stressUrgent ? "text-red-400 font-bold" : stressWarning ? "text-yellow-400" : "text-muted-foreground"}`}>
              <Clock className="h-3.5 w-3.5" />
              {isStressMode && !submitted ? (
                <motion.span animate={stressUrgent ? { scale: [1, 1.15, 1] } : {}} transition={{ repeat: stressUrgent ? Infinity : 0, duration: 0.8 }}>
                  {formatTime(timeRemaining)}
                </motion.span>
              ) : formatTime(elapsed)}
            </div>
            <Button variant="outline" size="sm" onClick={handleFinish} disabled={updateSession.isPending} className="text-xs h-7">End</Button>
          </div>
        </div>

        {/* Stress countdown bar */}
        {isStressMode && !submitted && (
          <motion.div className="mb-3">
            <div className="h-1 bg-muted rounded-full overflow-hidden">
              <motion.div
                className={`h-full rounded-full transition-colors ${stressUrgent ? "bg-red-500" : stressWarning ? "bg-yellow-500" : "bg-primary"}`}
                style={{ width: `${(timeRemaining / STRESS_TIME_LIMIT) * 100}%` }}
                transition={{ duration: 1 }}
              />
            </div>
            {stressUrgent && (
              <p className="text-xs text-red-400 mt-1 font-medium text-center">Time running out — submit now!</p>
            )}
          </motion.div>
        )}

        {/* Progress */}
        <div className="mb-4">
          <div className="flex justify-between text-xs text-muted-foreground mb-1.5">
            <span>Question {(session?.answeredQuestions ?? 0) + 1} of {session?.totalQuestions ?? 10}</span>
            <div className="flex items-center gap-3">
              {evaluation?.interviewerStyle && (
                <span className="text-muted-foreground capitalize hidden sm:block">
                  {INTERVIEWER_STYLE_LABEL[evaluation.interviewerStyle] ?? evaluation.interviewerStyle}
                </span>
              )}
              <span className="capitalize">{session?.skillLevel} level</span>
            </div>
          </div>
          <Progress value={((session?.answeredQuestions ?? 0) / (session?.totalQuestions ?? 10)) * 100} className="h-1.5" />
        </div>

        {/* Score mini-chart */}
        {scoreHistory.length >= 2 && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="mb-4">
            <Card className="bg-card border-border">
              <CardContent className="py-2 px-4">
                <div className="flex items-center gap-2 mb-1">
                  <Activity className="h-3.5 w-3.5 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">Score progression</span>
                </div>
                <ResponsiveContainer width="100%" height={40}>
                  <LineChart data={scoreHistory}>
                    <Line type="monotone" dataKey="score" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ fill: "hsl(var(--primary))", r: 2 }} />
                    <Line type="monotone" dataKey="conf" stroke="hsl(var(--chart-3))" strokeWidth={1.5} strokeDasharray="3 3" dot={false} />
                    <YAxis domain={[0, 100]} hide />
                    <Tooltip contentStyle={{ fontSize: "11px", backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: "6px" }} formatter={(v: any, name: string) => [`${v}%`, name === "score" ? "Quality" : "Confidence"]} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Question area */}
        <AnimatePresence mode="wait">
          {questionLoading ? (
            <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex items-center justify-center py-20">
              <div className="text-center"><Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-3" /><p className="text-sm text-muted-foreground">Loading next question...</p></div>
            </motion.div>
          ) : questionError ? (
            <motion.div key="error" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="text-center py-16">
              <AlertCircle className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
              <p className="text-muted-foreground text-sm mb-4">No more questions available for this level.</p>
              <Button onClick={handleFinish}>View Results</Button>
            </motion.div>
          ) : question ? (
            <motion.div key={question.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.3 }}>

              {/* Question card */}
              <Card className={`border-2 mb-3 ${isStressMode ? "border-red-500/20 bg-red-500/5" : "bg-card border-border"}`}>
                <CardContent className="pt-4 pb-4">
                  <div className="flex flex-wrap gap-1.5 mb-3">
                    <Badge variant="outline" className="capitalize text-xs">{question.topic}</Badge>
                    <Badge variant="outline" className={`capitalize text-xs ${question.difficulty === "advanced" ? "border-red-500/30 text-red-400" : question.difficulty === "intermediate" ? "border-yellow-500/30 text-yellow-400" : "border-green-500/30 text-green-400"}`}>{question.difficulty}</Badge>
                    <Badge variant="outline" className="capitalize text-xs">{question.type}</Badge>
                  </div>
                  <p className="text-base font-medium leading-relaxed">{question.text}</p>
                  {question.followUpPrompt && (
                    <p className="text-sm text-muted-foreground mt-3 border-l-2 border-primary/40 pl-3 italic">{question.followUpPrompt}</p>
                  )}
                </CardContent>
              </Card>

              {/* Hints */}
              {question.hints && question.hints.length > 0 && (
                <div className="mb-3">
                  <Button variant="ghost" size="sm" onClick={() => setShowHints(!showHints)} className="gap-1.5 text-muted-foreground text-xs h-7">
                    <Lightbulb className="h-3.5 w-3.5 text-yellow-400" />
                    {showHints ? "Hide hints" : "Show hints"}
                  </Button>
                  <AnimatePresence>
                    {showHints && (
                      <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="overflow-hidden">
                        <div className="mt-2 p-3 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                          <ul className="space-y-1">
                            {question.hints.map((hint, i) => (
                              <li key={i} className="text-xs text-yellow-300 flex gap-2"><span className="shrink-0">•</span>{hint}</li>
                            ))}
                          </ul>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              )}

              {/* Voice recording indicator */}
              {isVoiceMode && voiceStatus === "listening" && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mb-3 flex items-center gap-2 px-3 py-2 bg-red-500/10 border border-red-500/25 rounded-lg">
                  <motion.div animate={{ scale: [1, 1.3, 1] }} transition={{ repeat: Infinity, duration: 1.2 }}>
                    <Radio className="h-4 w-4 text-red-400" />
                  </motion.div>
                  <span className="text-xs text-red-400 font-medium">Recording — speak now</span>
                  {interimText && <span className="text-xs text-muted-foreground italic ml-auto truncate max-w-[180px]">"{interimText}"</span>}
                </motion.div>
              )}

              {voiceFallback && (
                <div className="mb-3 flex items-center gap-2 px-3 py-2 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                  <WifiOff className="h-3.5 w-3.5 text-yellow-400" />
                  <span className="text-xs text-yellow-400">Voice unavailable — using text mode</span>
                </div>
              )}

              {/* Answer input */}
              {!submitted && (
                <div className="space-y-2.5">
                  <div className="relative">
                    <Textarea
                      placeholder={isVoiceMode && voiceStatus !== "listening" ? "Click the microphone to start speaking, or type here..." : voiceStatus === "listening" ? "Speaking... (your words appear here)" : "Type your answer. Use STAR: Situation → Task → Action → Result..."}
                      value={answerText + (interimText ? " " + interimText : "")}
                      onChange={(e) => { if (voiceStatus === "listening") return; setAnswerText(e.target.value); }}
                      readOnly={voiceStatus === "listening"}
                      className="min-h-[140px] bg-background border-border text-sm resize-none"
                    />
                    <div className="absolute bottom-3 right-3">
                      <span className={`text-xs ${wordCount < 30 ? "text-muted-foreground" : wordCount >= 80 ? "text-green-400" : "text-yellow-400"}`}>{wordCount} words</span>
                    </div>
                  </div>
                  {wordCount > 0 && wordCount < 50 && <p className="text-xs text-muted-foreground">Aim for 80-150 words for a complete answer.</p>}
                  <div className="flex gap-2">
                    {isVoiceMode && (
                      <Button variant={voiceStatus === "listening" ? "destructive" : "outline"} size="icon" onClick={toggleRecording} className={`h-10 w-10 shrink-0 ${voiceStatus === "listening" ? "animate-pulse" : ""}`}>
                        {voiceStatus === "listening" ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                      </Button>
                    )}
                    <Button className="flex-1 gap-2" onClick={handleSubmit} disabled={!answerText.trim() || submitAnswer.isPending}>
                      {submitAnswer.isPending ? <><Loader2 className="h-4 w-4 animate-spin" /> Evaluating...</> : <><Send className="h-4 w-4" /> Submit Answer</>}
                    </Button>
                  </div>
                </div>
              )}

              {/* Evaluation results */}
              <AnimatePresence>
                {submitted && evaluation && (
                  <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }} className="space-y-3 mt-1">

                    {/* Scores */}
                    <div className="grid grid-cols-2 gap-3">
                      <Card className="bg-card border-border">
                        <CardContent className="pt-3 pb-2 px-4">
                          <div className="text-xs text-muted-foreground mb-1">Answer Quality</div>
                          <div className={`text-3xl font-bold ${evaluation.score >= 75 ? "text-green-400" : evaluation.score >= 50 ? "text-yellow-400" : "text-red-400"}`}>{evaluation.score}%</div>
                        </CardContent>
                      </Card>
                      <Card className="bg-card border-border">
                        <CardContent className="pt-3 pb-2 px-4">
                          <div className="text-xs text-muted-foreground mb-1">Confidence</div>
                          <div className="text-3xl font-bold text-primary">{evaluation.confidenceScore}%</div>
                        </CardContent>
                      </Card>
                    </div>

                    {/* Feedback */}
                    <Card className="bg-card border-border">
                      <CardContent className="pt-3 pb-3 px-4">
                        <p className="text-sm leading-relaxed">{evaluation.feedback}</p>
                        {evaluation.interviewerStyle && (
                          <p className="text-xs text-muted-foreground mt-2 border-t border-border pt-2">
                            Interviewer style: <span className="font-medium capitalize text-foreground">{evaluation.interviewerStyle}</span>
                          </p>
                        )}
                      </CardContent>
                    </Card>

                    {/* Strengths & Improvements */}
                    <div className="grid sm:grid-cols-2 gap-3">
                      {evaluation.strengths.length > 0 && (
                        <div>
                          <h4 className="text-xs font-semibold text-green-400 flex items-center gap-1 mb-2"><Check className="h-3 w-3" /> Strengths</h4>
                          <ul className="space-y-1.5">{evaluation.strengths.map((s, i) => <li key={i} className="text-xs text-muted-foreground flex gap-2"><span className="text-green-400 shrink-0 mt-0.5">•</span>{s}</li>)}</ul>
                        </div>
                      )}
                      {evaluation.improvements.length > 0 && (
                        <div>
                          <h4 className="text-xs font-semibold text-yellow-400 flex items-center gap-1 mb-2"><X className="h-3 w-3" /> To Improve</h4>
                          <ul className="space-y-1.5">{evaluation.improvements.map((s, i) => <li key={i} className="text-xs text-muted-foreground flex gap-2"><span className="text-yellow-400 shrink-0 mt-0.5">→</span>{s}</li>)}</ul>
                        </div>
                      )}
                    </div>

                    {/* Keywords */}
                    {evaluation.keywordMatches.length > 0 && (
                      <div>
                        <div className="text-xs text-muted-foreground mb-1.5">Keywords detected:</div>
                        <div className="flex flex-wrap gap-1.5">
                          {evaluation.keywordMatches.map((kw) => <Badge key={kw} variant="outline" className="text-xs bg-primary/10 text-primary border-primary/20">{kw}</Badge>)}
                        </div>
                      </div>
                    )}

                    {/* Follow-up question from interviewer */}
                    {evaluation.followUpQuestion && (
                      <AnimatePresence>
                        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                          <Card className="border-primary/30 bg-primary/5">
                            <CardContent className="py-3 px-4">
                              <div className="flex items-center gap-2 mb-2">
                                <MessageSquare className="h-3.5 w-3.5 text-primary shrink-0" />
                                <span className="text-xs font-semibold text-primary">Interviewer Follow-up</span>
                              </div>
                              <p className="text-sm text-foreground leading-relaxed italic">"{evaluation.followUpQuestion}"</p>
                              <p className="text-xs text-muted-foreground mt-2">This is a clarification question from your interviewer. Keep it in mind as you prepare for similar questions.</p>
                            </CardContent>
                          </Card>
                        </motion.div>
                      </AnimatePresence>
                    )}

                    {/* Difficulty change */}
                    {evaluation.difficultyAdjustment !== "maintain" && (
                      <div className={`text-xs px-3 py-2 rounded-lg flex items-center gap-2 ${evaluation.difficultyAdjustment === "increase" ? "bg-primary/10 text-primary border border-primary/20" : "bg-yellow-500/10 text-yellow-400 border border-yellow-500/20"}`}>
                        {evaluation.difficultyAdjustment === "increase" ? <TrendingUp className="h-3.5 w-3.5 shrink-0" /> : <TrendingDown className="h-3.5 w-3.5 shrink-0" />}
                        {evaluation.difficultyAdjustment === "increase" ? "Excellent — difficulty increasing for the next question." : "Questions will be slightly easier to help build momentum."}
                      </div>
                    )}

                    <Button className="w-full gap-2" onClick={handleNextQuestion}>
                      Next Question <ChevronRight className="h-4 w-4" />
                    </Button>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ) : null}
        </AnimatePresence>
      </div>
    </div>
  );
}
