import { useState } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Briefcase, Mic, Type, ChevronRight, ArrowLeft, Loader2, Zap, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useGetCompanies, useGetRolesForCompany, useCreateSession, getGetRolesForCompanyQueryKey } from "@workspace/api-client-react";
import { Link } from "wouter";

type Step = "company" | "role" | "type";

const COMPANY_STYLE: Record<string, { color: string; border: string; text: string; bg: string; letter: string }> = {
  amazon:    { color: "#FF9900", border: "border-[#FF9900]/40", text: "text-[#FF9900]", bg: "bg-[#FF9900]/10", letter: "A" },
  google:    { color: "#4285F4", border: "border-[#4285F4]/40", text: "text-[#4285F4]", bg: "bg-[#4285F4]/10", letter: "G" },
  microsoft: { color: "#00A4EF", border: "border-[#00A4EF]/40", text: "text-[#00A4EF]", bg: "bg-[#00A4EF]/10", letter: "M" },
  meta:      { color: "#1877F2", border: "border-[#1877F2]/40", text: "text-[#1877F2]", bg: "bg-[#1877F2]/10", letter: "M" },
  tcs:       { color: "#002B5C", border: "border-blue-800/40", text: "text-blue-400", bg: "bg-blue-900/20", letter: "T" },
  infosys:   { color: "#007CC3", border: "border-sky-500/40", text: "text-sky-400", bg: "bg-sky-900/20", letter: "I" },
  wipro:     { color: "#9333EA", border: "border-purple-500/40", text: "text-purple-400", bg: "bg-purple-900/20", letter: "W" },
  zoho:      { color: "#E42527", border: "border-red-500/40", text: "text-red-400", bg: "bg-red-900/20", letter: "Z" },
};

const DEFAULT_STYLE = { color: "hsl(var(--primary))", border: "border-primary/40", text: "text-primary", bg: "bg-primary/10", letter: "?" };

export default function Setup() {
  const [, navigate] = useLocation();
  const [step, setStep] = useState<Step>("company");
  const [selectedCompany, setSelectedCompany] = useState<string | null>(null);
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<"text" | "voice">("text");
  const [difficulty, setDifficulty] = useState<"beginner" | "intermediate" | "advanced" | undefined>(undefined);
  const [stressMode, setStressMode] = useState(false);

  const { data: companies, isLoading: companiesLoading } = useGetCompanies();
  const { data: roles, isLoading: rolesLoading } = useGetRolesForCompany(selectedCompany ?? "", {
    query: { enabled: !!selectedCompany, queryKey: getGetRolesForCompanyQueryKey(selectedCompany ?? "") },
  });
  const createSession = useCreateSession();

  const selectedCompanyData = companies?.find(c => c.id === selectedCompany);
  const selectedRoleData = roles?.find(r => r.id === selectedRole);

  const handleStartInterview = async () => {
    if (!selectedCompany || !selectedRole) return;
    const session = await createSession.mutateAsync({
      data: {
        companyId: selectedCompany,
        roleId: selectedRole,
        interviewType: selectedType,
        difficultyOverride: stressMode ? "advanced" : difficulty,
        mode: stressMode ? "stress" : "normal",
      },
    });
    navigate(`/interview/${session.id}`);
  };

  const steps: Step[] = ["company", "role", "type"];
  const stepLabels = ["Select Company", "Choose Role", "Interview Setup"];
  const currentIdx = steps.indexOf(step);

  return (
    <div className="min-h-screen px-4 py-8 md:px-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            {step !== "company" && (
              <Button variant="ghost" size="icon" onClick={() => setStep(step === "type" ? "role" : "company")} className="h-8 w-8 text-muted-foreground">
                <ArrowLeft className="h-4 w-4" />
              </Button>
            )}
            <div>
              <h1 className="text-2xl font-bold">Setup Interview</h1>
              <p className="text-sm text-muted-foreground">{stepLabels[currentIdx]}</p>
            </div>
          </div>
          {/* Step indicator */}
          <div className="flex gap-2 mt-4">
            {steps.map((s, i) => (
              <div key={s} className={`h-1 flex-1 rounded-full transition-all duration-500 ${i <= currentIdx ? "bg-primary" : "bg-muted"}`} />
            ))}
          </div>
        </motion.div>

        <AnimatePresence mode="wait">
          {/* Step 1: Company */}
          {step === "company" && (
            <motion.div key="company" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              {companiesLoading ? (
                <div className="flex items-center justify-center py-20">
                  <div className="text-center">
                    <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-3" />
                    <p className="text-sm text-muted-foreground">Loading companies...</p>
                  </div>
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 gap-3 mb-6">
                  {companies?.map((company, i) => {
                    const style = COMPANY_STYLE[company.id] ?? DEFAULT_STYLE;
                    const isSelected = selectedCompany === company.id;
                    return (
                      <motion.div key={company.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}>
                        <Card
                          onClick={() => setSelectedCompany(company.id)}
                          className={`cursor-pointer transition-all duration-200 hover:scale-[1.02] border-2 ${isSelected ? `${style.border} ${style.bg}` : "border-border bg-card hover:border-primary/30"}`}
                        >
                          <CardContent className="pt-4 pb-4 px-4">
                            <div className="flex items-start gap-3">
                              <div
                                className={`h-10 w-10 rounded-xl flex items-center justify-center text-base font-bold shrink-0 transition-all ${isSelected ? style.bg : "bg-muted/50"}`}
                                style={{ color: isSelected ? style.color : "hsl(var(--muted-foreground))" }}
                              >
                                {style.letter}
                              </div>
                              <div className="min-w-0 flex-1">
                                <div className={`font-semibold text-sm transition-colors ${isSelected ? style.text : "text-foreground"}`}>{company.name}</div>
                                <div className="text-xs text-muted-foreground mt-0.5">{company.industry}</div>
                                <div className="flex items-center gap-2 mt-2">
                                  <Badge variant="outline" className={`text-xs h-5 ${isSelected ? `${style.border} ${style.text}` : ""}`}>
                                    {company.questionCount} questions
                                  </Badge>
                                  {company.interviewerStyle && (
                                    <span className="text-xs text-muted-foreground capitalize">{company.interviewerStyle}</span>
                                  )}
                                </div>
                              </div>
                              {isSelected && (
                                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} className={`h-5 w-5 rounded-full flex items-center justify-center shrink-0`} style={{ backgroundColor: style.color }}>
                                  <svg className="h-3 w-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                                </motion.div>
                              )}
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    );
                  })}
                </div>
              )}

              <div className="flex items-center justify-between">
                <Link href="/resume">
                  <Button variant="ghost" size="sm" className="gap-2 text-muted-foreground">
                    <FileText className="h-3.5 w-3.5" />
                    Analyze my resume first
                  </Button>
                </Link>
                <Button disabled={!selectedCompany} onClick={() => setStep("role")} className="gap-2">
                  Next <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 2: Role */}
          {step === "role" && (
            <motion.div key="role" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>
              <div className="flex items-center gap-2 mb-4">
                {selectedCompanyData && (
                  <div className="flex items-center gap-2">
                    <div
                      className="h-7 w-7 rounded-lg flex items-center justify-center text-xs font-bold"
                      style={{ backgroundColor: `${(COMPANY_STYLE[selectedCompanyData.id] ?? DEFAULT_STYLE).color}22`, color: (COMPANY_STYLE[selectedCompanyData.id] ?? DEFAULT_STYLE).color }}
                    >
                      {(COMPANY_STYLE[selectedCompanyData.id] ?? DEFAULT_STYLE).letter}
                    </div>
                    <span className="font-semibold">{selectedCompanyData.name}</span>
                  </div>
                )}
                <span className="text-muted-foreground">— Choose a Role</span>
              </div>

              {rolesLoading ? (
                <div className="flex items-center justify-center py-16"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
              ) : (
                <div className="flex flex-col gap-2 mb-6">
                  {roles?.map((role, i) => (
                    <motion.div key={role.id} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.06 }}>
                      <Card
                        onClick={() => setSelectedRole(role.id)}
                        className={`cursor-pointer transition-all duration-200 hover:border-primary/40 border-2 ${selectedRole === role.id ? "border-primary bg-primary/10" : "border-border bg-card"}`}
                      >
                        <CardContent className="py-3 px-4">
                          <div className="flex items-start justify-between gap-3">
                            <div className="min-w-0">
                              <div className="font-semibold text-sm">{role.title}</div>
                              <div className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{role.description}</div>
                            </div>
                            <Badge variant="outline" className="text-xs shrink-0 mt-0.5 capitalize">{role.category}</Badge>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                  {(!roles || roles.length === 0) && (
                    <div className="text-center py-10 text-muted-foreground text-sm">No roles available for this company.</div>
                  )}
                </div>
              )}

              <div className="flex justify-end">
                <Button disabled={!selectedRole} onClick={() => setStep("type")} className="gap-2">
                  Next <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </motion.div>
          )}

          {/* Step 3: Interview Type + Settings */}
          {step === "type" && (
            <motion.div key="type" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }}>

              {/* Interview type */}
              <div className="grid sm:grid-cols-2 gap-3 mb-5">
                {[
                  { type: "text" as const, label: "Text Interview", icon: Type, description: "Type your answers — ideal for structured, detailed responses" },
                  { type: "voice" as const, label: "Voice Interview", icon: Mic, description: "Speak your answers — simulates a real interview environment" },
                ].map(({ type, label, icon: Icon, description }) => (
                  <Card
                    key={type}
                    onClick={() => setSelectedType(type)}
                    className={`cursor-pointer transition-all duration-200 border-2 hover:scale-[1.01] ${selectedType === type ? "border-primary bg-primary/10" : "border-border bg-card hover:border-primary/30"}`}
                  >
                    <CardContent className="pt-5 pb-4">
                      <Icon className={`h-6 w-6 mb-2 ${selectedType === type ? "text-primary" : "text-muted-foreground"}`} />
                      <div className="font-semibold text-sm mb-1">{label}</div>
                      <p className="text-xs text-muted-foreground leading-relaxed">{description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Difficulty */}
              <div className="mb-5">
                <Label className="text-sm font-medium mb-3 block">Starting Difficulty <span className="text-muted-foreground font-normal text-xs">(auto-adapts during interview)</span></Label>
                <div className="flex gap-2 flex-wrap">
                  {([undefined, "beginner", "intermediate", "advanced"] as const).map((d) => (
                    <Button key={d ?? "auto"} variant={difficulty === d ? "default" : "outline"} size="sm" onClick={() => setDifficulty(d)} className="capitalize text-xs h-8">
                      {d ?? "Auto"}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Stress mode toggle */}
              <Card className={`mb-5 border-2 transition-colors ${stressMode ? "border-red-500/40 bg-red-500/5" : "border-border bg-card"}`}>
                <CardContent className="py-4 px-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3">
                      <div className={`h-8 w-8 rounded-lg flex items-center justify-center shrink-0 ${stressMode ? "bg-red-500/20" : "bg-muted"}`}>
                        <Zap className={`h-4 w-4 ${stressMode ? "text-red-400" : "text-muted-foreground"}`} />
                      </div>
                      <div>
                        <div className={`text-sm font-semibold ${stressMode ? "text-red-400" : "text-foreground"}`}>Stress Test Mode</div>
                        <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                          45-second countdown per question. Advanced difficulty only. Stricter scoring. Simulates high-pressure interviews.
                        </p>
                      </div>
                    </div>
                    <Switch checked={stressMode} onCheckedChange={setStressMode} className="shrink-0 mt-0.5" />
                  </div>
                </CardContent>
              </Card>

              {/* Summary */}
              <Card className="bg-card border-border mb-6">
                <CardHeader className="pb-2 pt-4">
                  <CardTitle className="text-sm">Interview Summary</CardTitle>
                </CardHeader>
                <CardContent className="pb-4">
                  <div className="space-y-2 text-sm">
                    {[
                      { label: "Company", value: selectedCompanyData?.name ?? "—" },
                      { label: "Role", value: selectedRoleData?.title ?? "—" },
                      { label: "Input Mode", value: selectedType === "text" ? "Text" : "Voice" },
                      { label: "Difficulty", value: stressMode ? "Advanced (Stress)" : (difficulty ? difficulty.charAt(0).toUpperCase() + difficulty.slice(1) : "Auto") },
                      { label: "Mode", value: stressMode ? "Stress Test" : "Standard" },
                    ].map(({ label, value }) => (
                      <div key={label} className="flex justify-between items-center">
                        <span className="text-muted-foreground">{label}</span>
                        <span className={`font-medium capitalize ${label === "Mode" && stressMode ? "text-red-400" : "text-foreground"}`}>{value}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Button
                size="lg"
                className={`w-full gap-2 font-semibold ${stressMode ? "bg-red-600 hover:bg-red-700 text-white" : ""}`}
                onClick={handleStartInterview}
                disabled={createSession.isPending}
              >
                {createSession.isPending
                  ? <><Loader2 className="h-4 w-4 animate-spin" /> Starting...</>
                  : stressMode
                  ? <><Zap className="h-4 w-4" /> Begin Stress Test</>
                  : <><ChevronRight className="h-4 w-4" /> Start Interview</>
                }
              </Button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
