import { Link } from "wouter";
import { motion } from "framer-motion";
import { BrainCircuit, Play, BarChart2, TrendingUp, Target, Lightbulb, Clock, Star, Zap, Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useGetDashboard, useGetSkillLevel, useGetSessions } from "@workspace/api-client-react";

const features = [
  {
    icon: BrainCircuit,
    title: "Adaptive Questions",
    description: "Questions evolve based on your performance in real-time",
  },
  {
    icon: Zap,
    title: "NLP Evaluation",
    description: "AI scores your answers for quality, keywords, and structure",
  },
  {
    icon: TrendingUp,
    title: "Confidence Tracking",
    description: "Measures tone, response time, and filler words",
  },
  {
    icon: Target,
    title: "Weak Area Detection",
    description: "Identifies gaps and creates a personalized improvement plan",
  },
];

const statVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.1, duration: 0.4 } }),
};

export default function Home() {
  const { data: dashboard } = useGetDashboard();
  const { data: skillLevel } = useGetSkillLevel();
  const { data: sessions } = useGetSessions();

  const recentSessions = (sessions ?? []).slice(0, 3);

  return (
    <div className="min-h-screen overflow-x-hidden">
      {/* Hero Section */}
      <section className="relative px-6 pt-12 pb-8 md:pt-20 md:pb-12">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-transparent to-transparent pointer-events-none" />
        <div className="max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Badge variant="outline" className="mb-4 text-primary border-primary/40 bg-primary/10">
              Personalized Placement Trainer
            </Badge>
            <h1 className="text-3xl md:text-5xl font-extrabold tracking-tight mb-4">
              Your{" "}
              <span className="text-primary">AI Interview Twin</span>
              <br />
              that learns you.
            </h1>
            <p className="text-muted-foreground text-base md:text-lg mb-8 max-w-xl">
              Practice adaptive mock interviews for Amazon, Google, TCS, Zoho, and more.
              Get instant NLP-powered feedback on answer quality, confidence, and improvement areas.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Link href="/setup">
                <Button size="lg" className="gap-2 font-semibold text-base">
                  <Play className="h-5 w-5" />
                  Start Interview
                </Button>
              </Link>
              <Link href="/dashboard">
                <Button size="lg" variant="outline" className="gap-2">
                  <BarChart2 className="h-5 w-5" />
                  View Dashboard
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Overview */}
      {dashboard && (
        <section className="px-6 pb-8">
          <div className="max-w-3xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: "Sessions", value: dashboard.totalSessions, icon: Clock, color: "text-blue-400" },
              { label: "Avg Score", value: `${dashboard.averageScore}%`, icon: Star, color: "text-yellow-400" },
              { label: "Skill Level", value: dashboard.currentSkillLevel.charAt(0).toUpperCase() + dashboard.currentSkillLevel.slice(1), icon: Award, color: "text-primary" },
              { label: "Questions", value: dashboard.totalQuestionsAnswered, icon: Zap, color: "text-green-400" },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                custom={i}
                variants={statVariants}
                initial="hidden"
                animate="visible"
              >
                <Card className="bg-card border-card-border">
                  <CardContent className="pt-4 pb-3 px-4">
                    <div className="flex items-center gap-2 mb-1">
                      <stat.icon className={`h-4 w-4 ${stat.color}`} />
                      <span className="text-xs text-muted-foreground">{stat.label}</span>
                    </div>
                    <div className="text-2xl font-bold">{stat.value}</div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </section>
      )}

      {/* Skill Level Progress */}
      {skillLevel && (
        <section className="px-6 pb-8">
          <div className="max-w-3xl mx-auto">
            <Card className="bg-card border-card-border">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base">Your Skill Level</CardTitle>
                    <CardDescription className="text-sm mt-1">{skillLevel.description}</CardDescription>
                  </div>
                  <Badge
                    className={`capitalize font-semibold text-sm px-3 py-1 ${
                      skillLevel.level === "advanced"
                        ? "bg-primary/20 text-primary border-primary/30"
                        : skillLevel.level === "intermediate"
                        ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
                        : "bg-green-500/20 text-green-400 border-green-500/30"
                    }`}
                    variant="outline"
                  >
                    {skillLevel.level}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 mb-1">
                  <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                    <motion.div
                      className="h-full bg-primary rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${skillLevel.percentToNextLevel}%` }}
                      transition={{ duration: 0.8, ease: "easeOut" }}
                    />
                  </div>
                  <span className="text-xs text-muted-foreground">{skillLevel.percentToNextLevel}%</span>
                </div>
                <p className="text-xs text-muted-foreground mt-2">{skillLevel.nextLevelRequirements}</p>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Features */}
      <section className="px-6 pb-8">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-lg font-semibold mb-4 text-muted-foreground uppercase tracking-wide text-xs">What makes it different</h2>
          <div className="grid sm:grid-cols-2 gap-3">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 + 0.3 }}
              >
                <Card className="bg-card border-card-border h-full">
                  <CardContent className="pt-4">
                    <f.icon className="h-6 w-6 text-primary mb-2" />
                    <h3 className="font-semibold mb-1">{f.title}</h3>
                    <p className="text-sm text-muted-foreground">{f.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Recent Sessions */}
      {recentSessions.length > 0 && (
        <section className="px-6 pb-12">
          <div className="max-w-3xl mx-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Recent Sessions</h2>
              <Link href="/progress">
                <Button variant="ghost" size="sm" className="text-primary">
                  View all
                </Button>
              </Link>
            </div>
            <div className="flex flex-col gap-2">
              {recentSessions.map((s, i) => (
                <motion.div
                  key={s.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Link href={`/results/${s.id}`}>
                    <Card className="bg-card border-card-border hover:border-primary/40 transition-colors cursor-pointer">
                      <CardContent className="py-3 px-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="font-medium text-sm">{s.companyName} — {s.roleName}</div>
                            <div className="text-xs text-muted-foreground mt-0.5">
                              {s.answeredQuestions} questions · {new Date(s.createdAt).toLocaleDateString()}
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            {s.overallScore != null && (
                              <span className="text-lg font-bold text-primary">{Math.round(s.overallScore as number)}%</span>
                            )}
                            <Badge
                              variant="outline"
                              className={`capitalize text-xs ${
                                s.status === "completed"
                                  ? "border-green-500/30 text-green-400"
                                  : "border-yellow-500/30 text-yellow-400"
                              }`}
                            >
                              {s.status}
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA when no sessions */}
      {recentSessions.length === 0 && (
        <section className="px-6 pb-12">
          <div className="max-w-3xl mx-auto">
            <Card className="bg-card border-card-border border-dashed">
              <CardContent className="py-12 text-center">
                <BrainCircuit className="h-12 w-12 text-primary mx-auto mb-4 opacity-60" />
                <h3 className="font-semibold text-lg mb-2">Ready to practice?</h3>
                <p className="text-muted-foreground text-sm mb-6">
                  Start your first mock interview and get personalized feedback instantly.
                </p>
                <Link href="/setup">
                  <Button size="lg" className="gap-2">
                    <Play className="h-4 w-4" />
                    Start your first interview
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </section>
      )}
    </div>
  );
}
