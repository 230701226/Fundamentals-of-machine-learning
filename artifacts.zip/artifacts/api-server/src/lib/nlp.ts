export interface EvaluationResult {
  score: number;
  confidenceScore: number;
  feedback: string;
  strengths: string[];
  improvements: string[];
  keywordMatches: string[];
  starAnalysis: STARAnalysis;
  difficultyAdjustment: "increase" | "decrease" | "maintain";
  nextTopic: string;
  followUpQuestion: string | null;
  interviewerStyle: string;
}

export interface STARAnalysis {
  situation: boolean;
  task: boolean;
  action: boolean;
  result: boolean;
  score: number;
}

// Interviewer personality per company
const INTERVIEWER_PROFILES: Record<string, {
  style: string;
  tone: string;
  followUpProbability: number;
  clarificationTemplate: string;
  deepDiveTemplate: string;
  reasoningTemplate: string;
}> = {
  amazon: {
    style: "strict",
    tone: "Amazon Leadership Principles focused, probing, behaviorally rigorous",
    followUpProbability: 0.9,
    clarificationTemplate: "That's a start — but I need more specifics. Which Leadership Principle drove your decision here, and what was the quantified business impact?",
    deepDiveTemplate: "Strong answer. Now let's go deeper: if you had to scale that solution 10x, what would break first and how would you address it?",
    reasoningTemplate: "Walk me through your prioritization. How did you decide this was the right approach over alternatives, and what data informed that decision?",
  },
  google: {
    style: "analytical",
    tone: "Technical depth, system thinking, data-driven, open-ended exploration",
    followUpProbability: 0.85,
    clarificationTemplate: "Interesting perspective — can you quantify the tradeoffs? What metrics would you use to evaluate success here?",
    deepDiveTemplate: "Good foundation. Now let's stress-test it: what are the edge cases in your approach, and how does it behave at Google scale?",
    reasoningTemplate: "Walk me through your reasoning from first principles. What assumptions did you make, and how would changing them affect your approach?",
  },
  microsoft: {
    style: "collaborative",
    tone: "Growth mindset, collaborative problem solving, inclusive design",
    followUpProbability: 0.75,
    clarificationTemplate: "That's helpful context. How did you bring others along on that journey, and what would you do differently with a growth mindset now?",
    deepDiveTemplate: "Good thinking. How would you extend this solution to serve diverse users or teams with different needs?",
    reasoningTemplate: "Help me understand the collaboration aspect: who were your key stakeholders, and how did you build consensus around your approach?",
  },
  meta: {
    style: "impact-driven",
    tone: "Move fast, high ownership, measurable impact, cross-functional",
    followUpProbability: 0.8,
    clarificationTemplate: "What was the direct user or business impact? Give me numbers — MAU, revenue, latency reduction, whatever applies.",
    deepDiveTemplate: "Solid. How fast did you move from idea to production? What shortcuts did you take, and were they worth it?",
    reasoningTemplate: "How did you decide this was the highest-impact thing you could work on? What did you say no to, and why?",
  },
  tcs: {
    style: "friendly",
    tone: "Structured, communication-focused, process-oriented, client delivery",
    followUpProbability: 0.65,
    clarificationTemplate: "Thank you for that. Could you also explain how you communicated this to stakeholders or clients, and how you ensured everyone was aligned?",
    deepDiveTemplate: "Well structured. How would you document this process for your team, and what onboarding would you create for a new team member?",
    reasoningTemplate: "Could you explain the process you followed step by step? How did you ensure quality and meet client expectations?",
  },
  infosys: {
    style: "process-driven",
    tone: "Methodology, best practices, client focus, delivery excellence",
    followUpProbability: 0.65,
    clarificationTemplate: "Good answer. How did you ensure this followed best practices and industry standards? What framework or methodology guided you?",
    deepDiveTemplate: "Solid approach. How did you measure success metrics and report progress to leadership?",
    reasoningTemplate: "Walk me through the project lifecycle here. How did you handle risks, dependencies, and stakeholder communication?",
  },
  wipro: {
    style: "structured",
    tone: "Agile delivery, continuous improvement, cross-functional collaboration",
    followUpProbability: 0.65,
    clarificationTemplate: "Interesting. How did this fit into your team's sprint planning, and how did you handle blockers or scope changes?",
    deepDiveTemplate: "Good. How did you retrospectively improve this process in subsequent sprints or iterations?",
    reasoningTemplate: "What agile practices supported this work? How did daily standups or retrospectives shape the outcome?",
  },
  zoho: {
    style: "technical",
    tone: "Product thinking, frugal innovation, ownership, technical depth",
    followUpProbability: 0.7,
    clarificationTemplate: "Interesting approach — how did you validate this was the right solution before building? What did the prototype phase look like?",
    deepDiveTemplate: "Good thinking. How would you build this with minimal resources and still achieve the same quality outcome?",
    reasoningTemplate: "What was the product reasoning behind this decision? How did customer feedback shape your approach?",
  },
};

const DEFAULT_PROFILE = INTERVIEWER_PROFILES.amazon;

const FILLER_WORDS = [
  "um", "uh", "like", "you know", "basically", "literally", "actually",
  "so", "right", "kind of", "sort of", "i mean", "you see"
];

const STRONG_PHRASES = [
  "specifically", "for example", "for instance", "in my experience",
  "i implemented", "i led", "i designed", "i built", "i developed",
  "the result was", "this led to", "as a result", "we achieved",
  "i measured", "improved by", "reduced by", "increased by",
  "i owned", "i drove", "i delivered", "data shows", "metrics showed"
];

const STAR_PATTERNS = {
  situation: [
    "the situation", "at the time", "we were", "my team was", "the context was",
    "when i was working", "during my time at", "i was working on", "the project was",
    "we had a problem", "there was a challenge", "the background was", "to set the context",
    "in this scenario", "the challenge was", "we faced"
  ],
  task: [
    "my task was", "my responsibility was", "i was asked to", "i needed to",
    "my role was", "i was responsible for", "the goal was", "my objective was",
    "i was expected to", "i had to", "it was my job to", "the task required",
    "i was tasked with", "my deliverable was", "the requirement was"
  ],
  action: [
    "i decided to", "i took", "i started", "i implemented", "i created",
    "i built", "i worked on", "what i did", "my approach was", "i began by",
    "i analyzed", "i spoke with", "i reached out", "i proposed", "i designed",
    "i collaborated", "i coordinated", "i developed", "i established", "i introduced",
    "first i", "my first step", "to address this", "i initiated"
  ],
  result: [
    "the result", "as a result", "this led to", "we achieved", "we reduced",
    "we improved", "the outcome", "in the end", "ultimately", "this resulted in",
    "we saw", "the impact was", "we delivered", "we increased", "i learned",
    "the team was able to", "this helped", "we were able to", "the effect was",
    "by doing this", "this enabled", "the final outcome"
  ]
};

const KEYWORD_SYNONYMS: Record<string, string[]> = {
  "scalability": ["scale", "scaling", "horizontal", "vertical", "load", "distributed"],
  "performance": ["optimization", "optimize", "efficient", "latency", "throughput", "speed"],
  "leadership": ["lead", "led", "manage", "managed", "mentor", "guide", "direct"],
  "communication": ["communicated", "discussed", "presented", "collaborated", "coordinated", "articulated"],
  "problem-solving": ["solution", "solved", "resolved", "fixed", "debugged", "diagnosed"],
  "teamwork": ["team", "collaborate", "together", "cross-functional", "colleagues", "partnership"],
  "ownership": ["owned", "responsible", "drove", "initiated", "took charge", "accountable"],
  "innovation": ["innovative", "creative", "novel", "new approach", "pioneered", "invented"],
  "data": ["metrics", "analytics", "measurement", "kpi", "dashboard", "insight"],
  "agile": ["sprint", "scrum", "kanban", "iteration", "retrospective", "standup"],
};

function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

function detectSTAR(text: string): STARAnalysis {
  const lower = text.toLowerCase();
  const situation = STAR_PATTERNS.situation.some(p => lower.includes(p));
  const task = STAR_PATTERNS.task.some(p => lower.includes(p));
  const action = STAR_PATTERNS.action.some(p => lower.includes(p));
  const result = STAR_PATTERNS.result.some(p => lower.includes(p));
  const componentCount = [situation, task, action, result].filter(Boolean).length;
  const score = Math.round((componentCount / 4) * 100);
  return { situation, task, action, result, score };
}

function computeKeywordMatches(text: string, keywords: string[]): string[] {
  const lower = text.toLowerCase();
  const matched = new Set<string>();
  for (const kw of keywords) {
    const kwLower = kw.toLowerCase();
    if (lower.includes(kwLower)) { matched.add(kw); continue; }
    const synonyms = KEYWORD_SYNONYMS[kwLower] ?? [];
    if (synonyms.some(syn => lower.includes(syn))) matched.add(kw);
  }
  return Array.from(matched);
}

function computeConfidence(text: string, responseTimeSeconds: number): number {
  const lower = text.toLowerCase();
  const wordCount = countWords(text);
  let score = 55;

  const totalFillers = FILLER_WORDS.reduce((acc, fw) => {
    const regex = new RegExp(`\\b${fw.replace(/ /g, "\\s+")}\\b`, "gi");
    return acc + (lower.match(regex)?.length ?? 0);
  }, 0);
  const fillerDensity = wordCount > 0 ? totalFillers / wordCount : 0;
  score -= Math.min(fillerDensity * 100, 25);

  const strongCount = STRONG_PHRASES.reduce((acc, sp) => acc + (lower.includes(sp.toLowerCase()) ? 1 : 0), 0);
  score += Math.min(strongCount * 4, 20);

  const star = detectSTAR(text);
  score += Math.round(star.score * 0.1);

  if (wordCount < 20) score -= 20;
  else if (wordCount >= 80 && wordCount <= 350) score += 8;
  else if (wordCount > 500) score -= 5;

  if (responseTimeSeconds < 5) score -= 15;
  else if (responseTimeSeconds >= 10 && responseTimeSeconds <= 60) score += 8;
  else if (responseTimeSeconds > 180) score -= 5;

  return Math.max(10, Math.min(100, Math.round(score)));
}

function computeQualityScore(
  text: string,
  keywords: string[],
  difficulty: string,
  isStressMode: boolean
): number {
  const wordCount = countWords(text);
  const keywordHits = computeKeywordMatches(text, keywords).length;
  const keywordRatio = keywords.length > 0 ? keywordHits / keywords.length : 0;
  const lower = text.toLowerCase();
  const star = detectSTAR(text);

  let score = 30;
  score += Math.round(keywordRatio * 35);
  score += Math.round(star.score * 0.25);

  if (wordCount >= 60 && wordCount <= 350) score += 10;
  else if (wordCount < 20) score -= 20;
  else if (wordCount >= 20 && wordCount < 60) score += 3;
  else if (wordCount > 500) score -= 8;

  const hasExample = lower.includes("for example") || lower.includes("for instance") ||
    lower.includes("such as") || lower.includes("specifically,");
  if (hasExample) score += 5;

  const hasOutcome = lower.includes("result") || lower.includes("impact") ||
    lower.includes("outcome") || lower.includes("achieved") || lower.includes("reduced") ||
    lower.includes("improved") || lower.includes("increased");
  if (hasOutcome) score += 5;

  if (difficulty === "advanced") score = Math.max(score - 5, 10);
  else if (difficulty === "beginner") score = Math.min(score + 5, 100);

  // Stress mode is stricter
  if (isStressMode) score = Math.max(10, Math.round(score * 0.85));

  return Math.max(10, Math.min(100, Math.round(score)));
}

function generateFollowUpQuestion(
  score: number,
  companyId: string,
  topic: string
): string | null {
  const profile = INTERVIEWER_PROFILES[companyId.toLowerCase()] ?? DEFAULT_PROFILE;

  // Only generate with company's follow-up probability
  if (Math.random() > profile.followUpProbability) return null;

  if (score < 50) {
    return profile.clarificationTemplate;
  } else if (score > 70) {
    return profile.deepDiveTemplate;
  } else {
    return profile.reasoningTemplate;
  }
}

function generateFeedback(
  score: number,
  star: STARAnalysis,
  keywordRatio: number,
  strengths: string[],
  improvements: string[]
): string {
  const missingStarComponents = [
    !star.situation && "situation",
    !star.task && "task/goal",
    !star.action && "specific actions taken",
    !star.result && "measurable result/outcome"
  ].filter(Boolean) as string[];

  if (score >= 85) {
    return `Excellent answer. ${strengths[0] ?? "Clear structure and strong technical depth"}. ${improvements[0] ? `To push further: ${improvements[0].toLowerCase()}.` : "Keep it up."}`.trim();
  } else if (score >= 70) {
    return `Strong answer. ${strengths[0] ?? "You covered the key concepts well"}. ${missingStarComponents.length > 0 ? `Add the ${missingStarComponents.slice(0, 2).join(" and ")} to make it exceptional.` : improvements[0] ? `To elevate: ${improvements[0].toLowerCase()}` : ""}`.trim();
  } else if (score >= 50) {
    const kw = keywordRatio < 0.4 ? "Include more domain-specific terminology. " : "";
    const starNote = missingStarComponents.length >= 2
      ? `Try the STAR method — missing the ${missingStarComponents.slice(0, 2).join(" and ")}. `
      : "";
    return `Decent attempt. ${kw}${starNote}${improvements[0] ?? "Provide a concrete example with a measurable outcome"}.`;
  } else if (score >= 30) {
    return `Needs more depth. ${missingStarComponents.length > 2 ? "Structure using STAR: Situation, Task, Action, Result. " : ""}${improvements[0] ?? "Add specific examples from your experience"}.`;
  } else {
    return `This answer needs significant development. Walk through a real example using STAR: describe the Situation → your Task → the Actions you took → the measurable Result.`;
  }
}

export function evaluateAnswer(
  answerText: string,
  keywords: string[],
  difficulty: string,
  responseTimeSeconds: number,
  recentScores: number[],
  topic: string,
  companyId: string = "amazon",
  isStressMode: boolean = false
): EvaluationResult {
  const score = computeQualityScore(answerText, keywords, difficulty, isStressMode);
  const confidenceScore = computeConfidence(answerText, responseTimeSeconds);
  const keywordMatches = computeKeywordMatches(answerText, keywords);
  const star = detectSTAR(answerText);
  const keywordRatio = keywords.length > 0 ? keywordMatches.length / keywords.length : 0;

  const strengths: string[] = [];
  const improvements: string[] = [];

  if (star.score >= 75) strengths.push("Well-structured using the STAR method");
  else if (star.action && star.result) strengths.push("Good focus on actions and outcomes");

  if (keywordRatio >= 0.7) strengths.push("Strong use of relevant technical terminology");
  else if (keywordRatio >= 0.4) strengths.push("Good coverage of domain-specific concepts");

  if (countWords(answerText) >= 100) strengths.push("Comprehensive and detailed response");
  const lower = answerText.toLowerCase();
  if (lower.includes("result") || lower.includes("impact") || lower.includes("achieved")) {
    strengths.push("Focused on outcomes and measurable impact");
  }
  if (lower.includes("for example") || lower.includes("specifically")) {
    strengths.push("Used concrete examples to illustrate points");
  }

  if (!star.situation && !star.task) {
    improvements.push("Set the context first — briefly describe the situation and your specific role/task");
  } else if (!star.result) {
    improvements.push("Always close with the result: what was the measurable outcome or impact?");
  }

  if (keywordRatio < 0.35 && keywords.length > 0) {
    improvements.push(`Incorporate more relevant terms: ${keywords.slice(0, 3).join(", ")}`);
  }

  if (countWords(answerText) < 50) {
    improvements.push("Expand your answer — aim for 80-150 words with specific details");
  }

  if (confidenceScore < 50) {
    improvements.push("Reduce filler words (um, like, basically) and use stronger, more decisive language");
  }

  if (!lower.includes("result") && !lower.includes("impact") && !lower.includes("outcome")) {
    improvements.push("Quantify the impact where possible (e.g., 'reduced load time by 30%')");
  }

  if (strengths.length === 0) strengths.push("You addressed the question and showed willingness to engage");

  const avgRecentScore = recentScores.length > 0
    ? recentScores.reduce((s, v) => s + v, 0) / recentScores.length
    : score;

  let difficultyAdjustment: "increase" | "decrease" | "maintain" = "maintain";
  if (!isStressMode) {
    if (avgRecentScore >= 70 && score >= 65) difficultyAdjustment = "increase";
    else if (avgRecentScore < 40 || score < 35) difficultyAdjustment = "decrease";
  }

  const nextTopics: Record<string, string> = {
    "behavioral": "leadership",
    "leadership": "problem-solving",
    "problem-solving": "system-design",
    "system-design": "technical",
    "technical": "algorithms",
    "algorithms": "data-structures",
    "data-structures": "behavioral",
    "communication": "teamwork",
    "teamwork": "leadership",
  };
  const nextTopic = nextTopics[topic.toLowerCase()] ?? "behavioral";

  const profile = INTERVIEWER_PROFILES[companyId.toLowerCase()] ?? DEFAULT_PROFILE;
  const followUpQuestion = generateFollowUpQuestion(score, companyId, topic);

  return {
    score,
    confidenceScore,
    feedback: generateFeedback(score, star, keywordRatio, strengths, improvements),
    strengths,
    improvements,
    keywordMatches,
    starAnalysis: star,
    difficultyAdjustment,
    nextTopic,
    followUpQuestion,
    interviewerStyle: profile.style,
  };
}

export function classifySkillLevel(averageScore: number, answeredCount: number): string {
  if (answeredCount < 3) return "beginner";
  if (averageScore >= 72) return "advanced";
  if (averageScore >= 48) return "intermediate";
  return "beginner";
}

// Resume analysis
const SKILL_KEYWORDS: Record<string, string[]> = {
  "Python": ["python", "django", "flask", "fastapi", "pandas", "numpy", "scipy"],
  "JavaScript": ["javascript", "js", "nodejs", "node.js", "express", "next.js", "react", "vue", "angular"],
  "TypeScript": ["typescript", "ts"],
  "Java": ["java", "spring", "maven", "gradle", "hibernate", "jvm"],
  "SQL": ["sql", "mysql", "postgresql", "postgres", "sqlite", "database", "query", "orm"],
  "Machine Learning": ["machine learning", "ml", "deep learning", "neural network", "tensorflow", "pytorch", "sklearn", "nlp", "ai"],
  "System Design": ["system design", "microservices", "distributed", "scalability", "architecture", "kafka", "redis", "kubernetes"],
  "Data Structures": ["algorithms", "data structures", "leetcode", "dsa", "complexity", "big-o"],
  "Cloud": ["aws", "azure", "gcp", "cloud", "s3", "lambda", "docker", "kubernetes", "terraform"],
  "DevOps": ["ci/cd", "devops", "jenkins", "github actions", "deployment", "monitoring", "observability"],
  "React": ["react", "reactjs", "jsx", "hooks", "redux", "context api"],
  "Leadership": ["led", "managed", "team lead", "mentor", "technical lead", "architect", "principal"],
  "Communication": ["presentation", "stakeholder", "client", "documentation", "technical writing"],
  "Agile": ["agile", "scrum", "kanban", "sprint", "jira", "confluence"],
};

const TOPIC_FOR_SKILL: Record<string, string[]> = {
  "Python": ["technical", "algorithms", "data-structures"],
  "JavaScript": ["technical", "system-design"],
  "TypeScript": ["technical"],
  "Java": ["technical", "system-design", "algorithms"],
  "SQL": ["technical", "system-design"],
  "Machine Learning": ["technical", "system-design"],
  "System Design": ["system-design"],
  "Data Structures": ["algorithms", "data-structures", "technical"],
  "Cloud": ["system-design", "technical"],
  "DevOps": ["system-design", "technical"],
  "React": ["technical"],
  "Leadership": ["leadership", "behavioral"],
  "Communication": ["communication", "behavioral"],
  "Agile": ["behavioral", "leadership"],
};

export function analyzeResume(resumeText: string): {
  detectedSkills: string[];
  experienceLevel: string;
  suggestedTopics: string[];
  summary: string;
  questionTopics: string[];
} {
  const lower = resumeText.toLowerCase();
  const detectedSkills: string[] = [];

  for (const [skill, keywords] of Object.entries(SKILL_KEYWORDS)) {
    if (keywords.some(kw => lower.includes(kw))) {
      detectedSkills.push(skill);
    }
  }

  const yearsMatch = lower.match(/(\d+)\+?\s*years?/);
  const years = yearsMatch ? parseInt(yearsMatch[1]) : 0;
  let experienceLevel = "Entry Level";
  if (years >= 8) experienceLevel = "Senior / Staff";
  else if (years >= 4) experienceLevel = "Mid-Level";
  else if (years >= 2) experienceLevel = "Junior";

  const topicSet = new Set<string>();
  for (const skill of detectedSkills) {
    for (const topic of (TOPIC_FOR_SKILL[skill] ?? [])) {
      topicSet.add(topic);
    }
  }
  // Always include behavioral
  topicSet.add("behavioral");

  const suggestedTopics = Array.from(topicSet).slice(0, 6);
  const questionTopics = suggestedTopics;

  const summary = detectedSkills.length > 0
    ? `Detected ${detectedSkills.length} skill areas: ${detectedSkills.slice(0, 5).join(", ")}${detectedSkills.length > 5 ? ` and ${detectedSkills.length - 5} more` : ""}. Interview will prioritize ${suggestedTopics.slice(0, 3).join(", ")} topics.`
    : "No specific skills detected. Interview will cover general behavioral and problem-solving questions.";

  return { detectedSkills, experienceLevel, suggestedTopics, summary, questionTopics };
}
