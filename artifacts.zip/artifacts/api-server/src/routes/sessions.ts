import { Router, type IRouter, type Request } from "express";
import { db, sessionsTable, companiesTable, rolesTable, questionsTable, answersTable } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import {
  GetSessionsResponse,
  CreateSessionBody,
  GetSessionParams,
  GetSessionResponse,
  UpdateSessionParams,
  UpdateSessionBody,
  UpdateSessionResponse,
  GetNextQuestionParams,
  GetNextQuestionResponse,
  SubmitAnswerParams,
  SubmitAnswerBody,
  SubmitAnswerResponse,
  GetSessionReplayParams,
  GetSessionReplayResponse,
} from "@workspace/api-zod";
import { evaluateAnswer, classifySkillLevel } from "../lib/nlp";

const router: IRouter = Router();

function getUserId(req: Request): number | undefined {
  return req.session?.userId;
}

router.get("/sessions", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  const sessions = userId
    ? await db.select().from(sessionsTable).where(eq(sessionsTable.userId, userId)).orderBy(desc(sessionsTable.createdAt))
    : await db.select().from(sessionsTable).orderBy(desc(sessionsTable.createdAt));

  const companies = await db.select().from(companiesTable);
  const roles = await db.select().from(rolesTable);

  const enriched = sessions.map((s) => {
    const company = companies.find(c => c.id === s.companyId);
    const role = roles.find(r => r.id === s.roleId);
    return {
      ...s,
      mode: s.mode ?? "normal",
      companyName: company?.name ?? s.companyId,
      roleName: role?.title ?? s.roleId,
      overallScore: s.overallScore ? parseFloat(s.overallScore) : undefined,
      createdAt: s.createdAt.toISOString(),
      completedAt: s.completedAt?.toISOString() ?? null,
    };
  });

  res.json(GetSessionsResponse.parse(enriched));
});

router.post("/sessions", async (req, res): Promise<void> => {
  const parsed = CreateSessionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { companyId, roleId, interviewType, difficultyOverride, mode } = parsed.data;
  const userId = getUserId(req);
  const sessionMode = mode ?? "normal";

  const [company] = await db.select().from(companiesTable).where(eq(companiesTable.id, companyId));
  if (!company) { res.status(404).json({ error: "Company not found" }); return; }

  const [role] = await db.select().from(rolesTable).where(and(eq(rolesTable.id, roleId), eq(rolesTable.companyId, companyId)));
  if (!role) { res.status(404).json({ error: "Role not found" }); return; }

  const initialDifficulty = sessionMode === "stress" ? "advanced" : (difficultyOverride ?? "beginner");

  const [session] = await db
    .insert(sessionsTable)
    .values({ userId: userId ?? null, companyId, roleId, interviewType, mode: sessionMode, currentDifficulty: initialDifficulty, skillLevel: difficultyOverride ?? "beginner" })
    .returning();

  res.status(201).json(GetSessionsResponse.element.parse({
    ...session,
    mode: session.mode ?? "normal",
    companyName: company.name,
    roleName: role.title,
    overallScore: undefined,
    createdAt: session.createdAt.toISOString(),
    completedAt: null,
  }));
});

router.get("/sessions/:sessionId", async (req, res): Promise<void> => {
  const params = GetSessionParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, params.data.sessionId));
  if (!session) { res.status(404).json({ error: "Session not found" }); return; }

  const [company] = await db.select().from(companiesTable).where(eq(companiesTable.id, session.companyId));
  const [role] = await db.select().from(rolesTable).where(eq(rolesTable.id, session.roleId));

  const sessionAnswers = await db.select().from(answersTable).where(eq(answersTable.sessionId, session.id)).orderBy(answersTable.createdAt);

  const answerRecords = await Promise.all(
    sessionAnswers.map(async (a) => {
      const [q] = await db.select().from(questionsTable).where(eq(questionsTable.id, a.questionId));
      return { id: a.id, questionId: a.questionId, questionText: q?.text ?? "", answerText: a.answerText, score: parseFloat(a.score), confidenceScore: parseFloat(a.confidenceScore), responseTimeSeconds: parseFloat(a.responseTimeSeconds), feedback: a.feedback ?? "", topic: q?.topic ?? "", difficulty: q?.difficulty ?? "" };
    })
  );

  res.json(GetSessionResponse.parse({
    ...session,
    mode: session.mode ?? "normal",
    companyName: company?.name ?? session.companyId,
    roleName: role?.title ?? session.roleId,
    overallScore: session.overallScore ? parseFloat(session.overallScore) : undefined,
    createdAt: session.createdAt.toISOString(),
    completedAt: session.completedAt?.toISOString() ?? null,
    answers: answerRecords,
  }));
});

router.patch("/sessions/:sessionId", async (req, res): Promise<void> => {
  const params = UpdateSessionParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const parsed = UpdateSessionBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const updateData: Record<string, unknown> = {};
  if (parsed.data.status) {
    updateData.status = parsed.data.status;
    if (parsed.data.status === "completed") {
      updateData.completedAt = new Date();
      const sessionAnswers = await db.select({ score: answersTable.score }).from(answersTable).where(eq(answersTable.sessionId, params.data.sessionId));
      if (sessionAnswers.length > 0) {
        const avg = sessionAnswers.reduce((sum, a) => sum + parseFloat(a.score), 0) / sessionAnswers.length;
        updateData.overallScore = avg.toFixed(2);
        updateData.skillLevel = classifySkillLevel(avg, sessionAnswers.length);
      }
    }
  }

  const [session] = await db.update(sessionsTable).set(updateData).where(eq(sessionsTable.id, params.data.sessionId)).returning();
  if (!session) { res.status(404).json({ error: "Session not found" }); return; }

  const [company] = await db.select().from(companiesTable).where(eq(companiesTable.id, session.companyId));
  const [role] = await db.select().from(rolesTable).where(eq(rolesTable.id, session.roleId));

  res.json(UpdateSessionResponse.parse({
    ...session,
    mode: session.mode ?? "normal",
    companyName: company?.name ?? session.companyId,
    roleName: role?.title ?? session.roleId,
    overallScore: session.overallScore ? parseFloat(session.overallScore) : undefined,
    createdAt: session.createdAt.toISOString(),
    completedAt: session.completedAt?.toISOString() ?? null,
  }));
});

router.get("/sessions/:sessionId/next-question", async (req, res): Promise<void> => {
  const params = GetNextQuestionParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, params.data.sessionId));
  if (!session) { res.status(404).json({ error: "Session not found" }); return; }

  const answeredIds = await db.select({ questionId: answersTable.questionId }).from(answersTable).where(eq(answersTable.sessionId, session.id));
  const answeredSet = new Set(answeredIds.map(a => a.questionId));

  const targetDifficulty = session.mode === "stress" ? "advanced" : session.currentDifficulty;

  const questions = await db.select().from(questionsTable).where(and(eq(questionsTable.companyId, session.companyId), eq(questionsTable.difficulty, targetDifficulty)));
  const available = questions.filter(q => !answeredSet.has(q.id));

  if (available.length === 0) {
    const anyDifficulty = await db.select().from(questionsTable).where(eq(questionsTable.companyId, session.companyId));
    const fallback = anyDifficulty.filter(q => !answeredSet.has(q.id));
    if (fallback.length === 0) { res.status(404).json({ error: "No more questions available" }); return; }
    const q = fallback[Math.floor(Math.random() * fallback.length)];
    res.json(GetNextQuestionResponse.parse({ ...q, hints: q.hints ?? [], followUpPrompt: q.followUpPrompt ?? null }));
    return;
  }

  const q = available[Math.floor(Math.random() * available.length)];
  res.json(GetNextQuestionResponse.parse({ ...q, hints: q.hints ?? [], followUpPrompt: q.followUpPrompt ?? null }));
});

router.post("/sessions/:sessionId/answers", async (req, res): Promise<void> => {
  const params = SubmitAnswerParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }
  const parsed = SubmitAnswerBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: parsed.error.message }); return; }

  const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, params.data.sessionId));
  if (!session) { res.status(404).json({ error: "Session not found" }); return; }

  const [question] = await db.select().from(questionsTable).where(eq(questionsTable.id, parsed.data.questionId));
  if (!question) { res.status(404).json({ error: "Question not found" }); return; }

  const recentAnswers = await db.select({ score: answersTable.score }).from(answersTable).where(eq(answersTable.sessionId, session.id)).orderBy(desc(answersTable.createdAt)).limit(3);
  const recentScores = recentAnswers.map(a => parseFloat(a.score));
  const isStressMode = session.mode === "stress";

  const evaluation = evaluateAnswer(
    parsed.data.answerText,
    question.keywords ?? [],
    question.difficulty,
    parsed.data.responseTimeSeconds,
    recentScores,
    question.topic,
    session.companyId,
    isStressMode
  );

  await db.insert(answersTable).values({
    sessionId: session.id,
    questionId: question.id,
    answerText: parsed.data.answerText,
    responseTimeSeconds: parsed.data.responseTimeSeconds.toString(),
    score: evaluation.score.toString(),
    confidenceScore: evaluation.confidenceScore.toString(),
    feedback: evaluation.feedback,
    strengths: evaluation.strengths,
    improvements: evaluation.improvements,
    keywordMatches: evaluation.keywordMatches,
  });

  const newAnsweredCount = session.answeredQuestions + 1;
  const allAnswers = await db.select({ score: answersTable.score }).from(answersTable).where(eq(answersTable.sessionId, session.id));
  const avgScore = allAnswers.reduce((sum, a) => sum + parseFloat(a.score), 0) / allAnswers.length;
  const newSkillLevel = classifySkillLevel(avgScore, allAnswers.length);

  let newDifficulty = session.currentDifficulty;
  if (!isStressMode) {
    if (evaluation.difficultyAdjustment === "increase") newDifficulty = session.currentDifficulty === "beginner" ? "intermediate" : "advanced";
    else if (evaluation.difficultyAdjustment === "decrease") newDifficulty = session.currentDifficulty === "advanced" ? "intermediate" : "beginner";
  }

  await db.update(sessionsTable).set({ answeredQuestions: newAnsweredCount, currentDifficulty: newDifficulty, skillLevel: newSkillLevel, overallScore: avgScore.toFixed(2) }).where(eq(sessionsTable.id, session.id));

  res.json(SubmitAnswerResponse.parse({
    score: evaluation.score,
    confidenceScore: evaluation.confidenceScore,
    feedback: evaluation.feedback,
    strengths: evaluation.strengths,
    improvements: evaluation.improvements,
    keywordMatches: evaluation.keywordMatches,
    difficultyAdjustment: evaluation.difficultyAdjustment,
    nextTopic: evaluation.nextTopic,
    followUpQuestion: evaluation.followUpQuestion ?? null,
    interviewerStyle: evaluation.interviewerStyle ?? null,
  }));
});

router.get("/sessions/:sessionId/replay", async (req, res): Promise<void> => {
  const params = GetSessionReplayParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, params.data.sessionId));
  if (!session) { res.status(404).json({ error: "Session not found" }); return; }

  const [company] = await db.select().from(companiesTable).where(eq(companiesTable.id, session.companyId));
  const [role] = await db.select().from(rolesTable).where(eq(rolesTable.id, session.roleId));

  const sessionAnswers = await db.select().from(answersTable).where(eq(answersTable.sessionId, session.id)).orderBy(answersTable.createdAt);

  const replayAnswers = await Promise.all(
    sessionAnswers.map(async (a, i) => {
      const [q] = await db.select().from(questionsTable).where(eq(questionsTable.id, a.questionId));
      return {
        questionNumber: i + 1,
        questionText: q?.text ?? "",
        answerText: a.answerText,
        score: parseFloat(a.score),
        confidenceScore: parseFloat(a.confidenceScore),
        feedback: a.feedback ?? "",
        topic: q?.topic ?? "",
        difficulty: q?.difficulty ?? "",
        responseTimeSeconds: parseFloat(a.responseTimeSeconds),
      };
    })
  );

  res.json(GetSessionReplayResponse.parse({
    sessionId: session.id,
    companyName: company?.name ?? session.companyId,
    roleName: role?.title ?? session.roleId,
    totalQuestions: session.totalQuestions,
    overallScore: session.overallScore ? parseFloat(session.overallScore) : null,
    createdAt: session.createdAt.toISOString(),
    answers: replayAnswers,
  }));
});

export default router;
