import { Router, type IRouter, type Request } from "express";
import { db, sessionsTable, answersTable, questionsTable, companiesTable, rolesTable } from "@workspace/db";
import { eq, desc, inArray } from "drizzle-orm";
import {
  GetDashboardResponse,
  GetProgressResponse,
  GetWeakAreasResponse,
  GetSkillLevelResponse,
  GetRecommendationsResponse,
  GetSessionAnalyticsParams,
  GetSessionAnalyticsResponse,
  GetCompanyReadinessResponse,
} from "@workspace/api-zod";
import { classifySkillLevel } from "../lib/nlp";

const router: IRouter = Router();

function getUserId(req: Request): number | undefined {
  return req.session?.userId;
}

async function getUserSessions(userId: number | undefined) {
  if (userId) {
    return db.select().from(sessionsTable).where(eq(sessionsTable.userId, userId)).orderBy(desc(sessionsTable.createdAt));
  }
  return db.select().from(sessionsTable).orderBy(desc(sessionsTable.createdAt));
}

async function getUserAnswers(sessionIds: number[]) {
  if (sessionIds.length === 0) return [];
  return db.select().from(answersTable).where(inArray(answersTable.sessionId, sessionIds));
}

// Company-specific topic weights for readiness scoring
const COMPANY_TOPIC_WEIGHTS: Record<string, Record<string, number>> = {
  amazon:    { behavioral: 0.30, leadership: 0.25, "system-design": 0.25, algorithms: 0.20 },
  google:    { algorithms: 0.35, "system-design": 0.30, technical: 0.25, communication: 0.10 },
  microsoft: { behavioral: 0.30, technical: 0.30, "system-design": 0.20, leadership: 0.20 },
  meta:      { "system-design": 0.30, algorithms: 0.25, behavioral: 0.25, technical: 0.20 },
  tcs:       { communication: 0.35, behavioral: 0.35, technical: 0.20, "problem-solving": 0.10 },
  infosys:   { communication: 0.30, behavioral: 0.30, technical: 0.25, "problem-solving": 0.15 },
  wipro:     { behavioral: 0.35, technical: 0.25, communication: 0.25, leadership: 0.15 },
  zoho:      { technical: 0.40, "problem-solving": 0.30, behavioral: 0.20, communication: 0.10 },
};

router.get("/analytics/dashboard", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  const sessions = await getUserSessions(userId);
  const companies = await db.select().from(companiesTable);
  const roles = await db.select().from(rolesTable);

  const sessionIds = sessions.map(s => s.id);
  const allAnswers = await getUserAnswers(sessionIds);

  const completedSessions = sessions.filter(s => s.status === "completed");
  const scores = allAnswers.map(a => parseFloat(a.score));
  const confScores = allAnswers.map(a => parseFloat(a.confidenceScore));
  const responseTimes = allAnswers.map(a => parseFloat(a.responseTimeSeconds));

  const avgScore = scores.length > 0 ? scores.reduce((s, v) => s + v, 0) / scores.length : 0;
  const avgConf = confScores.length > 0 ? confScores.reduce((s, v) => s + v, 0) / confScores.length : 0;
  const avgResponseTime = responseTimes.length > 0 ? responseTimes.reduce((s, v) => s + v, 0) / responseTimes.length : 0;

  const recent5 = completedSessions.slice(0, 5).map(s => parseFloat(s.overallScore ?? "0"));
  const prev5 = completedSessions.slice(5, 10).map(s => parseFloat(s.overallScore ?? "0"));
  const avgRecent = recent5.length > 0 ? recent5.reduce((s, v) => s + v, 0) / recent5.length : 0;
  const avgPrev = prev5.length > 0 ? prev5.reduce((s, v) => s + v, 0) / prev5.length : 0;
  const improvementRate = avgPrev > 0 ? ((avgRecent - avgPrev) / avgPrev) * 100 : 0;

  const topicMap: Record<string, { scores: number[]; count: number }> = {};
  const questionCache: Record<number, { topic: string }> = {};

  for (const answer of allAnswers) {
    if (!questionCache[answer.questionId]) {
      const [q] = await db.select({ topic: questionsTable.topic }).from(questionsTable).where(eq(questionsTable.id, answer.questionId));
      questionCache[answer.questionId] = { topic: q?.topic ?? "general" };
    }
    const topic = questionCache[answer.questionId].topic;
    if (!topicMap[topic]) topicMap[topic] = { scores: [], count: 0 };
    topicMap[topic].scores.push(parseFloat(answer.score));
    topicMap[topic].count++;
  }

  const topicBreakdown = Object.entries(topicMap).map(([topic, data]) => {
    const topicAvg = data.scores.reduce((s, v) => s + v, 0) / data.scores.length;
    const trend: "improving" | "declining" | "stable" =
      data.scores.length >= 2
        ? data.scores[data.scores.length - 1] > data.scores[0] + 3 ? "improving"
          : data.scores[data.scores.length - 1] < data.scores[0] - 3 ? "declining" : "stable"
        : "stable";
    return { topic, averageScore: Math.round(topicAvg * 10) / 10, questionsAnswered: data.count, trend };
  });

  const recentSessions = sessions.slice(0, 10).map(s => {
    const company = companies.find(c => c.id === s.companyId);
    const role = roles.find(r => r.id === s.roleId);
    return { ...s, mode: s.mode ?? "normal", companyName: company?.name ?? s.companyId, roleName: role?.title ?? s.roleId, overallScore: s.overallScore ? parseFloat(s.overallScore) : undefined, createdAt: s.createdAt.toISOString(), completedAt: s.completedAt?.toISOString() ?? null };
  });

  const currentSkillLevel = classifySkillLevel(avgScore, allAnswers.length);

  res.json(GetDashboardResponse.parse({
    totalSessions: sessions.length,
    completedSessions: completedSessions.length,
    averageScore: Math.round(avgScore * 10) / 10,
    averageConfidence: Math.round(avgConf * 10) / 10,
    currentSkillLevel,
    totalQuestionsAnswered: allAnswers.length,
    averageResponseTime: Math.round(avgResponseTime * 10) / 10,
    improvementRate: Math.round(improvementRate * 10) / 10,
    topicBreakdown,
    recentSessions,
  }));
});

router.get("/analytics/progress", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  const companies = await db.select().from(companiesTable);
  const roles = await db.select().from(rolesTable);

  const sessions = userId
    ? await db.select().from(sessionsTable).where(eq(sessionsTable.userId, userId)).orderBy(sessionsTable.createdAt)
    : await db.select().from(sessionsTable).where(eq(sessionsTable.status, "completed")).orderBy(sessionsTable.createdAt);

  const completedSessions = sessions.filter(s => s.status === "completed");

  const progressPoints = await Promise.all(
    completedSessions.map(async (s) => {
      const sessionAnswers = await db.select({ confScore: answersTable.confidenceScore }).from(answersTable).where(eq(answersTable.sessionId, s.id));
      const avgConf = sessionAnswers.length > 0 ? sessionAnswers.reduce((sum, a) => sum + parseFloat(a.confScore), 0) / sessionAnswers.length : 0;
      const company = companies.find(c => c.id === s.companyId);
      const role = roles.find(r => r.id === s.roleId);
      return { sessionId: s.id, date: s.createdAt.toISOString(), score: parseFloat(s.overallScore ?? "0"), confidenceScore: Math.round(avgConf * 10) / 10, skillLevel: s.skillLevel, company: company?.name ?? s.companyId, role: role?.title ?? s.roleId };
    })
  );

  res.json(GetProgressResponse.parse(progressPoints));
});

router.get("/analytics/weak-areas", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  const sessions = await getUserSessions(userId);
  const sessionIds = sessions.map(s => s.id);
  const allAnswers = await getUserAnswers(sessionIds);

  const topicMap: Record<string, { scores: number[]; improvements: string[][] }> = {};

  for (const answer of allAnswers) {
    const [q] = await db.select({ topic: questionsTable.topic }).from(questionsTable).where(eq(questionsTable.id, answer.questionId));
    const topic = q?.topic ?? "general";
    if (!topicMap[topic]) topicMap[topic] = { scores: [], improvements: [] };
    topicMap[topic].scores.push(parseFloat(answer.score));
    if (answer.improvements) topicMap[topic].improvements.push(answer.improvements as string[]);
  }

  const weakAreas = Object.entries(topicMap)
    .map(([topic, data]) => {
      const avgScore = data.scores.reduce((s, v) => s + v, 0) / data.scores.length;
      const allSuggestions = data.improvements.flat();
      const uniqueSuggestions = [...new Set(allSuggestions)].slice(0, 3);
      if (uniqueSuggestions.length === 0) {
        uniqueSuggestions.push(`Practice more ${topic} questions with structured STAR-format answers`);
        uniqueSuggestions.push(`Review core concepts and terminology related to ${topic}`);
        uniqueSuggestions.push(`Use the STAR method: Situation, Task, Action, Result for every answer`);
      }
      const priority: "high" | "medium" | "low" = avgScore < 40 ? "high" : avgScore < 60 ? "medium" : "low";
      return { topic, averageScore: Math.round(avgScore * 10) / 10, questionsAttempted: data.scores.length, suggestions: uniqueSuggestions, priority };
    })
    .filter(wa => wa.averageScore < 72)
    .sort((a, b) => a.averageScore - b.averageScore);

  res.json(GetWeakAreasResponse.parse(weakAreas));
});

router.get("/analytics/skill-level", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  const sessions = await getUserSessions(userId);
  const sessionIds = sessions.map(s => s.id);
  const allAnswers = await getUserAnswers(sessionIds);

  const scores = allAnswers.map(a => parseFloat(a.score));
  const avgScore = scores.length > 0 ? scores.reduce((s, v) => s + v, 0) / scores.length : 0;
  const level = classifySkillLevel(avgScore, scores.length);

  const descriptions: Record<string, string> = {
    beginner: "Building your foundation. Focus on understanding core concepts and using the STAR method consistently.",
    intermediate: "Solid fundamentals. Work on depth, concrete examples, and quantified outcomes.",
    advanced: "Demonstrating expertise. Focus on system design, edge case handling, and leadership narratives.",
  };
  const nextLevelReqs: Record<string, string> = {
    beginner: "Score above 48% on average across at least 3 sessions to reach Intermediate",
    intermediate: "Score above 72% on average across at least 3 sessions to reach Advanced",
    advanced: "You're at the highest level — maintain consistency and sharpen system design skills",
  };
  const percentToNext: Record<string, number> = {
    beginner: Math.min(100, Math.round((avgScore / 48) * 100)),
    intermediate: Math.min(100, Math.round(((avgScore - 48) / 24) * 100)),
    advanced: 100,
  };

  res.json(GetSkillLevelResponse.parse({
    level,
    score: Math.round(avgScore * 10) / 10,
    description: descriptions[level],
    nextLevelRequirements: nextLevelReqs[level],
    percentToNextLevel: percentToNext[level] ?? 0,
  }));
});

router.get("/analytics/recommendations", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  const sessions = await getUserSessions(userId);
  const sessionIds = sessions.map(s => s.id);
  const allAnswers = await getUserAnswers(sessionIds);

  const topicMap: Record<string, number[]> = {};
  for (const answer of allAnswers) {
    const [q] = await db.select({ topic: questionsTable.topic }).from(questionsTable).where(eq(questionsTable.id, answer.questionId));
    const topic = q?.topic ?? "general";
    if (!topicMap[topic]) topicMap[topic] = [];
    topicMap[topic].push(parseFloat(answer.score));
  }

  const allRecommendations = [
    { topic: "behavioral", reason: "Behavioral questions appear in 90% of interviews across all companies and roles", difficulty: "intermediate", estimatedImpact: "Very high — directly determines hiring decisions", sampleQuestion: "Tell me about a time you had to work with a difficult team member. How did you handle the situation and what was the outcome?", actionableSteps: ["Practice 3 STAR stories daily", "Focus on quantified outcomes", "Prepare for Amazon Leadership Principles"] },
    { topic: "system-design", reason: "System design differentiates senior candidates and shows architectural thinking", difficulty: "advanced", estimatedImpact: "Very high — critical for senior and staff-level roles", sampleQuestion: "Design a URL shortening service like bit.ly. Walk me through your approach, including scalability considerations.", actionableSteps: ["Study CAP theorem and distributed systems", "Practice designing for 10M+ users", "Draw system diagrams before answering"] },
    { topic: "problem-solving", reason: "Analytical problem-solving is tested by every major tech company", difficulty: "intermediate", estimatedImpact: "High — demonstrates structured thinking under pressure", sampleQuestion: "How would you debug a performance regression that only appears in production with millions of active users?", actionableSteps: ["Use structured frameworks (5-Why, fishbone)", "Always clarify constraints first", "Think aloud during your reasoning"] },
    { topic: "leadership", reason: "Leadership skills are valued at all levels, not just management roles", difficulty: "intermediate", estimatedImpact: "High — shows growth mindset and influence without authority", sampleQuestion: "Describe a project where you had to make a critical technical decision under uncertainty. What was your process?", actionableSteps: ["Prepare conflict resolution examples", "Practice ownership and accountability narratives", "Highlight cross-functional collaboration"] },
    { topic: "technical", reason: "Core technical depth validates your domain expertise and hands-on skills", difficulty: "advanced", estimatedImpact: "High — validates the depth behind your resume claims", sampleQuestion: "Explain the difference between concurrency and parallelism, and give a real example where you chose one over the other.", actionableSteps: ["Review fundamentals of your primary stack", "Prepare 2-3 technical deep-dive stories", "Explain tradeoffs in your design decisions"] },
    { topic: "communication", reason: "Clear technical communication is often overlooked but highly valued by interviewers", difficulty: "beginner", estimatedImpact: "Medium — enables you to present ideas clearly at all levels", sampleQuestion: "Explain a complex technical concept you worked on to a non-technical stakeholder. How did you ensure clarity?", actionableSteps: ["Practice explaining concepts without jargon", "Use analogies to simplify complex ideas", "Check for understanding during explanations"] },
  ];

  const weak = Object.entries(topicMap).map(([topic, scores]) => ({ topic, avg: scores.reduce((s, v) => s + v, 0) / scores.length })).filter(t => t.avg < 60).sort((a, b) => a.avg - b.avg);
  const prioritized = [...weak.map(w => allRecommendations.find(r => r.topic === w.topic)).filter(Boolean), ...allRecommendations.filter(r => !weak.find(w => w.topic === r.topic))].filter((r): r is NonNullable<typeof r> => r !== undefined).slice(0, 5);

  res.json(GetRecommendationsResponse.parse(prioritized));
});

router.get("/analytics/company-readiness", async (req, res): Promise<void> => {
  const userId = getUserId(req);
  const allSessions = await getUserSessions(userId);
  const companies = await db.select().from(companiesTable);

  // Group sessions by company
  const sessionsByCompany: Record<string, typeof allSessions> = {};
  for (const s of allSessions) {
    if (!sessionsByCompany[s.companyId]) sessionsByCompany[s.companyId] = [];
    sessionsByCompany[s.companyId].push(s);
  }

  const readinessItems = [];

  for (const [companyId, sessions] of Object.entries(sessionsByCompany)) {
    if (sessions.length === 0) continue;
    const company = companies.find(c => c.id === companyId);
    if (!company) continue;

    const sessionIds = sessions.map(s => s.id);
    const answers = await getUserAnswers(sessionIds);
    if (answers.length === 0) continue;

    // Compute topic scores for this company
    const topicMap: Record<string, number[]> = {};
    for (const answer of answers) {
      const [q] = await db.select({ topic: questionsTable.topic }).from(questionsTable).where(eq(questionsTable.id, answer.questionId));
      const topic = q?.topic ?? "general";
      if (!topicMap[topic]) topicMap[topic] = [];
      topicMap[topic].push(parseFloat(answer.score));
    }

    const topicBreakdown = Object.entries(topicMap).map(([topic, scores]) => ({
      topic,
      averageScore: Math.round((scores.reduce((s, v) => s + v, 0) / scores.length) * 10) / 10,
      questionsAnswered: scores.length,
      trend: scores.length >= 2
        ? scores[scores.length - 1] > scores[0] + 3 ? "improving" as const
          : scores[scores.length - 1] < scores[0] - 3 ? "declining" as const : "stable" as const
        : "stable" as const,
    }));

    // Compute weighted readiness score using company-specific weights
    const weights = COMPANY_TOPIC_WEIGHTS[companyId.toLowerCase()] ?? { behavioral: 0.30, technical: 0.25, "system-design": 0.25, leadership: 0.20 };
    let weightedScore = 0;
    let totalWeight = 0;

    for (const [topic, weight] of Object.entries(weights)) {
      const topicData = topicMap[topic];
      if (topicData && topicData.length > 0) {
        const avg = topicData.reduce((s, v) => s + v, 0) / topicData.length;
        weightedScore += avg * weight;
        totalWeight += weight;
      }
    }

    // Fallback: plain average if no weighted topics matched
    let readinessScore: number;
    if (totalWeight > 0) {
      const unweightedAvg = answers.reduce((s, a) => s + parseFloat(a.score), 0) / answers.length;
      readinessScore = (weightedScore / totalWeight) * 0.7 + unweightedAvg * 0.3;
    } else {
      readinessScore = answers.reduce((s, a) => s + parseFloat(a.score), 0) / answers.length;
    }

    readinessScore = Math.round(readinessScore * 10) / 10;
    const readinessLevel: "strong" | "medium" | "weak" = readinessScore >= 70 ? "strong" : readinessScore >= 50 ? "medium" : "weak";

    readinessItems.push({ companyId, companyName: company.name, readinessScore, readinessLevel, topicBreakdown });
  }

  readinessItems.sort((a, b) => b.readinessScore - a.readinessScore);
  res.json(GetCompanyReadinessResponse.parse(readinessItems));
});

router.get("/analytics/sessions/:sessionId", async (req, res): Promise<void> => {
  const params = GetSessionAnalyticsParams.safeParse(req.params);
  if (!params.success) { res.status(400).json({ error: params.error.message }); return; }

  const [session] = await db.select().from(sessionsTable).where(eq(sessionsTable.id, params.data.sessionId));
  if (!session) { res.status(404).json({ error: "Session not found" }); return; }

  const sessionAnswers = await db.select().from(answersTable).where(eq(answersTable.sessionId, session.id)).orderBy(answersTable.createdAt);

  const scores = sessionAnswers.map(a => parseFloat(a.score));
  const confScores = sessionAnswers.map(a => parseFloat(a.confidenceScore));
  const responseTimes = sessionAnswers.map(a => parseFloat(a.responseTimeSeconds));

  const avgScore = scores.length > 0 ? scores.reduce((s, v) => s + v, 0) / scores.length : 0;
  const avgConf = confScores.length > 0 ? confScores.reduce((s, v) => s + v, 0) / confScores.length : 0;
  const avgTime = responseTimes.length > 0 ? responseTimes.reduce((s, v) => s + v, 0) / responseTimes.length : 0;

  const topicMap: Record<string, number[]> = {};
  for (const answer of sessionAnswers) {
    const [q] = await db.select({ topic: questionsTable.topic }).from(questionsTable).where(eq(questionsTable.id, answer.questionId));
    const topic = q?.topic ?? "general";
    if (!topicMap[topic]) topicMap[topic] = [];
    topicMap[topic].push(parseFloat(answer.score));
  }

  const topicScores = Object.entries(topicMap).map(([topic, s]) => ({ topic, averageScore: Math.round((s.reduce((a, v) => a + v, 0) / s.length) * 10) / 10, questionsAnswered: s.length, trend: "stable" as const }));
  const allStrengths = sessionAnswers.flatMap(a => a.strengths as string[]);
  const allImprovements = sessionAnswers.flatMap(a => a.improvements as string[]);

  res.json(GetSessionAnalyticsResponse.parse({
    sessionId: session.id,
    overallScore: Math.round(avgScore * 10) / 10,
    confidenceScore: Math.round(avgConf * 10) / 10,
    averageResponseTime: Math.round(avgTime * 10) / 10,
    totalQuestions: session.totalQuestions,
    answeredQuestions: session.answeredQuestions,
    topicScores,
    scoreProgression: scores,
    strengths: [...new Set(allStrengths)].slice(0, 4),
    improvements: [...new Set(allImprovements)].slice(0, 4),
  }));
});

export default router;
