import { Router, type IRouter } from "express";
import { AnalyzeResumeBody, AnalyzeResumeResponse } from "@workspace/api-zod";
import { analyzeResume } from "../lib/nlp";

const router: IRouter = Router();

router.post("/resume/analyze", async (req, res): Promise<void> => {
  const parsed = AnalyzeResumeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  if (!parsed.data.resumeText.trim()) {
    res.status(400).json({ error: "Resume text cannot be empty" });
    return;
  }

  const result = analyzeResume(parsed.data.resumeText);
  res.json(AnalyzeResumeResponse.parse(result));
});

export default router;
