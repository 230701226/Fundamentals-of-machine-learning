import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import companiesRouter from "./companies";
import sessionsRouter from "./sessions";
import analyticsRouter from "./analytics";
import resumeRouter from "./resume";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(companiesRouter);
router.use(sessionsRouter);
router.use(analyticsRouter);
router.use(resumeRouter);

export default router;
