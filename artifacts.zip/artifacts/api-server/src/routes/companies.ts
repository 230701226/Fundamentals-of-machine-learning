import { Router, type IRouter } from "express";
import { db, companiesTable, rolesTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import {
  GetCompaniesResponse,
  GetRolesForCompanyParams,
  GetRolesForCompanyResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/companies", async (_req, res): Promise<void> => {
  const companies = await db.select().from(companiesTable);
  res.json(GetCompaniesResponse.parse(companies));
});

router.get("/companies/:companyId/roles", async (req, res): Promise<void> => {
  const params = GetRolesForCompanyParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const roles = await db
    .select()
    .from(rolesTable)
    .where(eq(rolesTable.companyId, params.data.companyId));

  res.json(GetRolesForCompanyResponse.parse(roles));
});

export default router;
